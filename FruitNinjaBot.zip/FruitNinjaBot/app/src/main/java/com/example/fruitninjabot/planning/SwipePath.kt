package com.example.fruitninjabot.planning

import com.example.fruitninjabot.tracking.TrackedObject
import com.example.fruitninjabot.util.Point

/**
 * A planned swipe: an ordered list of waypoints (screen pixel coordinates, ROI-relative — the
 * caller is responsible for offsetting into full-screen coordinates before dispatching a
 * gesture) plus the total duration and the fruit ids it is expected to hit.
 *
 * [waypoints] always has at least 2 points (start, end); combo swipes have intermediate points
 * between each targeted fruit so the resulting gesture is a smooth multi-point path rather than
 * a straight teleport between the first and last fruit.
 */
data class SwipePath(
    val waypoints: List<Point>,
    val durationMillis: Long,
    val targetTrackIds: List<Int>,
    val score: Float
) {
    val totalLength: Float
        get() {
            var sum = 0f
            for (i in 1 until waypoints.size) {
                sum += com.example.fruitninjabot.util.Geometry.distance(waypoints[i - 1], waypoints[i])
            }
            return sum
        }
}

/** Why the planner did or didn't produce a swipe this cycle — surfaced to the UI/state machine. */
sealed class PlanResult {
    data class Planned(val path: SwipePath) : PlanResult()
    data class Rejected(val reason: RejectionReason) : PlanResult()

    enum class RejectionReason {
        NO_TARGETS,
        ALL_TARGETS_LOW_CONFIDENCE,
        NO_SAFE_PATH_FOUND,
        BOMB_TOO_CLOSE_TO_EVERY_CANDIDATE
    }
}

/** Convenience for callers that just want the fruits considered "live" targets right now. */
fun List<TrackedObject>.fruitsOnly() = filter { it.type == com.example.fruitninjabot.detection.ObjectClass.FRUIT }

fun List<TrackedObject>.bombsOnly() = filter { it.type == com.example.fruitninjabot.detection.ObjectClass.BOMB }

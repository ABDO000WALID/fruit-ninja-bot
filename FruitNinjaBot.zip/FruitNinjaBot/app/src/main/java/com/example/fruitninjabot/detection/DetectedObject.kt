package com.example.fruitninjabot.detection

/**
 * Classification produced by an [ObjectDetector] for a single connected region found in a frame.
 *
 * FRUIT and BOMB are the only actionable categories. UNKNOWN is kept for regions that pass basic
 * size/shape filtering but whose color/shape signature does not clearly match either fruit or
 * bomb heuristics — these are ignored by the planner.
 */
enum class ObjectClass {
    FRUIT,
    BOMB,
    UNKNOWN
}

/**
 * A single detected region in one analyzed frame, in ROI-relative pixel coordinates (i.e.
 * already offset so that (0,0) is the top-left of the configured Region Of Interest, not the
 * full screen).
 *
 * This is intentionally a plain, immutable data class with no Android framework dependencies so
 * it can be unit tested on the JVM without an emulator.
 */
data class DetectedObject(
    val type: ObjectClass,
    val centerX: Float,
    val centerY: Float,
    val width: Float,
    val height: Float,
    val confidence: Float,
    val timestamp: Long
) {
    val left: Float get() = centerX - width / 2f
    val right: Float get() = centerX + width / 2f
    val top: Float get() = centerY - height / 2f
    val bottom: Float get() = centerY + height / 2f

    val area: Float get() = width * height
}

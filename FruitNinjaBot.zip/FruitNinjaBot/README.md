# Fruit Ninja Bot

An experimental, fully on-device Android accessibility/automation bot for Fruit Ninja. Screen
capture, detection, tracking, and path planning all run locally on the phone; nothing is
uploaded anywhere, and no frame is ever written to disk.

## Architecture

```
CaptureService (MediaProjection + ImageReader, foreground service)
        │  Bitmap (ROI-cropped), throttled to configured FPS
        ▼
BotController (state machine: STOPPED→STARTING→CAPTURING→ANALYZING→PLANNING→SWIPING/PAUSED/ERROR)
        │
        ├─► OpenCvObjectDetector (detection/) — HSV threshold + connected components → DetectedObject[]
        │
        ├─► ObjectTracker (tracking/) — nearest-neighbor match + velocity → TrackedObject[]
        │
        ├─► SafeSwipePlanner (planning/) — bomb-avoidance + combo scoring → SwipePath or Rejected
        │
        └─► BotAccessibilityService — dispatchGesture() only if a safe plan was found
```

- **MainActivity** — permission flows (MediaProjection, Accessibility, overlay, notifications) and
  the primary Start/Pause/Stop UI.
- **CaptureService** — owns MediaProjection, VirtualDisplay, and ImageReader. Converts frames to a
  reused Bitmap, crops to the ROI, throttles to the configured FPS, and closes every `Image`
  immediately after copying its pixels.
- **BotAccessibilityService** — the only component that calls `dispatchGesture()`. Refuses to
  start a second gesture while one is in flight.
- **detection/** — `ObjectDetector` interface + `OpenCvObjectDetector`. See the naming note in that
  file: it does **not** link the native OpenCV SDK (packaging that AAR reliably from a text-based
  delivery is fragile), so it implements an equivalent HSV/connected-components pipeline with pure
  Android `Bitmap`/`Color` APIs instead. Swappable later for real OpenCV or a TFLite model without
  touching anything downstream.
- **tracking/** — `ObjectTracker`, a lightweight greedy nearest-neighbor tracker with
  finite-difference velocity estimation. No ML model.
- **planning/** — `SafeSwipePlanner`. This is the safety-critical piece: it only ever returns a
  path that has already been checked against every bomb's safety radius (including its predicted
  position). If nothing safe can be built, it returns a typed rejection reason instead of a path —
  there is no code path that swipes without that check passing first.
- **overlay/DebugOverlayService** — optional, disabled by default, non-touchable overlay window
  drawing detection boxes and the planned path.
- **settings/SettingsRepository** — SharedPreferences-backed config for FPS, swipe duration,
  safety radius, confidence, combo mode, ROI, and overlay toggles.
- **RoiCalibrationActivity / TestModeActivity** — calibration UI and the synthetic test harness
  (tap = place fruit, long-press = place bomb, "Plan" runs the real planner) requested for testing
  without opening the game.

## Android-version notes discovered while building this

- **Android 14+ (API 34) MediaProjection ordering**: the foreground service must already be in the
  foreground (i.e. `startForeground()` must have already been called) **before** you call
  `MediaProjectionManager.getMediaProjection()`. `CaptureService.onStartCommand` does this in the
  correct order: `startForegroundNotification()` first, then `beginCapture()`.
- **`MediaProjection.Callback` registration is mandatory** before creating a `VirtualDisplay` on
  recent Android versions, or the system will tear the projection down. Handled in
  `beginCapture()`.
- **`foregroundServiceType="mediaProjection"`** must be declared in the manifest (done) and, on
  API 29+, passed to `ServiceCompat.startForeground(...)` as well (done, with the version-check
  fallback to a plain `startForeground()` on older devices).
- **`POST_NOTIFICATIONS` is a runtime permission on API 33+.** If the user denies it, the
  foreground service still runs (Android requires the notification to be *postable*, not that the
  user *see* it) — the app just won't show a visible ongoing notification, so `MainActivity`
  requests it up front but doesn't block on the result.
- **`Settings.canDrawOverlays()`** gates the optional debug overlay; the overlay service fails
  safe (stops itself) rather than crashing if permission is missing.
- This project targets `compileSdk`/`targetSdk` 35. If your installed Android Studio's bundled SDK
  Platform 35 isn't downloaded yet, Android Studio will prompt you to install it on first sync.

## What this bot does *not* claim

- The detector is a tunable HSV/shape heuristic, not a trained model — it **will** misclassify
  some fruit (especially dark-skinned fruit like kiwi) and some bomb lighting conditions. Treat the
  confidence threshold and safety radius in Settings as the primary tuning knobs.
- No specific score or win-rate is guaranteed.
- It has only been designed against the general, publicly documented shape of Fruit Ninja's
  gameplay (colorful fruit vs. dark bombs sliced by continuous swipes) — it has not been verified
  against every regional build or version of the game.

---

## 1. Opening the project in Android Studio

1. Install a recent stable Android Studio (Ladybird/2024.x or newer recommended for compileSdk 35
   support).
2. `File → Open`, select the `FruitNinjaBot` project root (the folder containing
   `settings.gradle.kts`).
3. This delivery does **not** include the binary `gradle/wrapper/gradle-wrapper.jar` (it's a
   compiled binary, not source text). Android Studio will detect the missing wrapper JAR on first
   open and offer to regenerate it automatically — accept that prompt. If it doesn't prompt, open
   a terminal in the project root and run:
   ```
   gradle wrapper --gradle-version 8.9
   ```
   (requires a system-installed Gradle just for this one-time step; alternatively use Android
   Studio's own bundled Gradle via `Tools → Gradle → ...` or simply let Android Studio's sync
   regenerate it, which it does automatically for projects opened directly in the IDE).
4. Let Gradle sync complete. If prompted to install SDK Platform 35 or a specific Build-Tools
   version, accept.

## 2. Building the APK

- **From Android Studio:** `Build → Build Bundle(s) / APK(s) → Build APK(s)`. The output APK will
  be at `app/build/outputs/apk/debug/app-debug.apk`.
- **From the command line** (after the wrapper JAR exists per step 3 above):
  ```
  ./gradlew assembleDebug
  ```
  Output: `app/build/outputs/apk/debug/app-debug.apk`.

## 3. Installing on a POCO X7 Pro

1. On the phone: **Settings → About phone**, tap "MIUI version" (or "Build number") 7 times to
   enable Developer Options, then enable **USB debugging** in **Settings → Additional settings →
   Developer options**.
2. Also in Developer options, disable **"MIUI optimization"** if you hit install/permission
   weirdness (some MIUI builds restrict accessibility/overlay APIs more aggressively than stock
   Android) — this is optional but recommended for a smoother first run.
3. Connect the phone via USB, accept the debugging prompt, then either:
   - Click the green **Run** button in Android Studio with the device selected, or
   - Run `adb install -r app/build/outputs/apk/debug/app-debug.apk` from the project root.
4. On first launch, if Android/MIUI blocks the "unknown app" install, tap **Settings** in the
   install prompt and allow installs from that source.

## 4. Enabling Accessibility

1. Open the app, tap **Enable Accessibility**. This opens the system Accessibility settings
   screen.
2. On MIUI this is usually under **Downloaded services** or **Installed services**. Find
   **"Fruit Ninja Bot Gesture Service"** and toggle it on.
3. Confirm the "This service needs permission to perform gestures" dialog if shown.
4. Return to the app — the **Accessibility: ON/OFF** status line updates the next time the app is
   in the foreground.

## 5. Granting MediaProjection (screen capture)

1. Tap **Start Screen Capture**.
2. Android will show a system dialog: "Fruit Ninja Bot wants to start capturing everything
   displayed on your screen." Tap **Start now**.
3. A persistent notification ("Fruit Ninja Bot is watching the screen — Local, on-device
   processing only") appears while capture is active — this is required by Android for any
   screen-recording app and cannot be hidden.
4. **Screen Capture: ON** should appear in the app's status card.

## 6. (Optional but recommended) Calibrating the ROI

1. Tap **Calibrate ROI**.
2. Drag the two blue handles so the rectangle matches Fruit Ninja's actual play area, excluding
   the status bar and any on-screen buttons.
3. Tap **Save ROI**. This is stored as a resolution-independent fraction of the screen, so it
   survives rotation and (mostly) different Fruit Ninja UI layouts.

## 7. Testing the swipe safely (no game needed)

1. With Accessibility enabled, tap **Test Swipe (Safe)**. This performs a single small
   diagonal swipe near the screen center — it does not depend on capture, detection, or Fruit
   Ninja being open. Use it on your home screen first to confirm gestures actually move a finger
   on-screen (you'll see it in e.g. a text field if you tap into one first).
2. For deeper testing without the game at all, tap **Test Mode (Synthetic — no game needed)**:
   tap to place synthetic fruit, long-press to place a synthetic bomb, then tap **Plan** to see
   exactly what `SafeSwipePlanner` would do — including a `REJECTED` result with the specific
   reason if you place a bomb on top of a fruit.

## 8. Starting the bot

1. Open Fruit Ninja and get into a game mode (Classic/Arcade/Zen).
2. Switch back to Fruit Ninja Bot is not necessary — with capture and accessibility both on, you
   can just tap **Start Bot** from the app, then switch to Fruit Ninja. The bot keeps running in
   the background via the foreground service and accessibility service.
3. **The bot will not swipe automatically until you explicitly tap Start Bot** — this is enforced
   in `BotController.startBot()`, which itself checks that both Accessibility and Screen Capture
   are active before flipping `botRunning = true`.
4. Use **Pause** to freeze swiping instantly without tearing down capture (useful to hand back
   manual control mid-game), and **Stop** to fully tear down capture and the bot state machine.

## 9. Troubleshooting

| Symptom | Likely cause / fix |
|---|---|
| "Bot error: Accessibility service is not enabled" toast | The accessibility toggle was turned off (or never enabled) — repeat step 4. |
| "Bot error: Screen capture is not active" | MediaProjection wasn't granted, or the system killed the foreground service (e.g. aggressive MIUI battery optimization). Disable battery optimization for the app in **Settings → Apps → Fruit Ninja Bot → Battery saver → No restrictions**, and re-tap Start Screen Capture. |
| Capture stops a few seconds after starting | Some MIUI builds treat `VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR` differently after screen-off/on; reopening the app and tapping Start Screen Capture again re-creates the VirtualDisplay. |
| Test Swipe does nothing visible | You're not focused on something that shows a swipe (e.g. try it over a scrollable list or text field first). Also confirm Accessibility is actually toggled on in system settings, not just requested. |
| Bot never swipes, "Rejected unsafe plans" keeps climbing | Expected if a bomb is near every visible fruit, or if `Minimum confidence` in Settings is set too high for your device's screen brightness/resolution. Lower `Minimum confidence` slightly, or increase `Bomb safety radius` if bombs are being missed rather than over-flagged. |
| Detector confuses background art for fruit | The heuristic thresholds in `OpenCvObjectDetector.DetectorTuning` are tuned generically; adjust `minSaturationForFruit` / `maxValueForBomb` for your specific device's color calibration, or re-run **Calibrate ROI** to exclude a busy background area. |
| Build fails: "SDK Platform 35 not found" | Open **Tools → SDK Manager** in Android Studio and install Android 15.0 (API 35) platform + matching Build-Tools. |
| `./gradlew` fails with "gradle-wrapper.jar is missing" | Expected for this text-based delivery — open the project in Android Studio once (it regenerates the wrapper automatically) or run `gradle wrapper --gradle-version 8.9` manually, then re-run `./gradlew`. |
| App installs but crashes immediately on launch | Check `adb logcat *:E` while launching — most likely a missing SDK Platform 35 / Build-Tools mismatch caught at build time rather than runtime, but if it does reach runtime, file the stack trace against the specific service/activity named in the trace. |

## Unit tests

Run with:
```
./gradlew testDebugUnitTest
```
Covers: bomb/path segment-circle intersection, point-to-segment distance, ROI normalization and
pixel conversion, nearest-neighbor object tracking (id continuity, velocity sign, cross-class
non-matching, stale-track eviction), and `SafeSwipePlanner` (confidence filtering, bomb avoidance
producing a specific rejection reason, combo-vs-single scoring, combo-mode toggle, and prediction
horizon projection).

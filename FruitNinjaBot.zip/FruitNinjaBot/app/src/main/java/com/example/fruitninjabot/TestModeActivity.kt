package com.example.fruitninjabot

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Bundle
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.fruitninjabot.detection.ObjectClass
import com.example.fruitninjabot.planning.PlanResult
import com.example.fruitninjabot.planning.SafeSwipePlanner
import com.example.fruitninjabot.tracking.TrackedObject

/**
 * "Internal test mode": lets a developer place synthetic fruit and bomb markers on screen and
 * immediately see what [SafeSwipePlanner] would do — without Fruit Ninja installed, without
 * MediaProjection, and without the accessibility service. This exists purely to validate/tune
 * planner behavior (bomb-avoidance radius, combo scoring, confidence thresholds) quickly.
 *
 * Controls:
 *  - Tap: place a fruit
 *  - Long-press: place a bomb
 *  - "Plan" button: run the planner against the current synthetic objects and draw the result
 *  - "Clear" button: remove all markers
 */
class TestModeActivity : AppCompatActivity() {

    private val syntheticObjects = mutableListOf<TrackedObject>()
    private var nextId = 1
    private lateinit var canvasView: TestCanvasView
    private lateinit var resultText: TextView
    private val planner = SafeSwipePlanner()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = FrameLayout(this)
        canvasView = TestCanvasView(this)
        root.addView(canvasView, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        resultText = TextView(this).apply {
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#AA000000"))
            setPadding(24, 24, 24, 24)
            text = "Tap = fruit, long-press = bomb. Press Plan to test SafeSwipePlanner."
        }
        root.addView(
            resultText,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                gravity = Gravity.TOP
            }
        )

        val buttonRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val planButton = Button(this).apply {
            text = "Plan"
            setOnClickListener { runPlanner() }
        }
        val clearButton = Button(this).apply {
            text = "Clear"
            setOnClickListener {
                syntheticObjects.clear()
                canvasView.setPlanResult(null)
                canvasView.invalidate()
                resultText.text = "Cleared."
            }
        }
        val backButton = Button(this).apply {
            text = "Close"
            setOnClickListener { finish() }
        }
        buttonRow.addView(planButton)
        buttonRow.addView(clearButton)
        buttonRow.addView(backButton)
        root.addView(
            buttonRow,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                bottomMargin = 48
            }
        )

        setContentView(root)
    }

    private fun runPlanner() {
        val now = SystemClock.elapsedRealtime()
        val result = planner.plan(syntheticObjects, predictionHorizonMillis = 0L, nowMillis = now)
        canvasView.setPlanResult(result)
        canvasView.invalidate()
        resultText.text = when (result) {
            is PlanResult.Planned -> "PLANNED: hits ${result.path.targetTrackIds} score=${"%.1f".format(result.path.score)}"
            is PlanResult.Rejected -> "REJECTED: ${result.reason} — bot will NOT swipe."
        }
    }

    private inner class TestCanvasView(context: android.content.Context) : View(context) {
        private var lastResult: PlanResult? = null
        private val fruitPaint = Paint().apply { color = Color.parseColor("#FF00E676") }
        private val bombPaint = Paint().apply { color = Color.parseColor("#FFFF1744") }
        private val pathPaint = Paint().apply {
            color = Color.parseColor("#FF2979FF"); style = Paint.Style.STROKE; strokeWidth = 6f
        }

        private val gestureDetector = android.view.GestureDetector(
            context,
            object : android.view.GestureDetector.SimpleOnGestureListener() {
                override fun onSingleTapUp(e: MotionEvent): Boolean {
                    syntheticObjects.add(
                        TrackedObject(
                            id = nextId++, type = ObjectClass.FRUIT, x = e.x, y = e.y,
                            vx = 0f, vy = 0f, confidence = 0.9f,
                            lastSeen = SystemClock.elapsedRealtime(), hitStreak = 3
                        )
                    )
                    invalidate()
                    return true
                }

                override fun onLongPress(e: MotionEvent) {
                    syntheticObjects.add(
                        TrackedObject(
                            id = nextId++, type = ObjectClass.BOMB, x = e.x, y = e.y,
                            vx = 0f, vy = 0f, confidence = 0.9f,
                            lastSeen = SystemClock.elapsedRealtime(), hitStreak = 3
                        )
                    )
                    invalidate()
                }
            }
        )

        fun setPlanResult(result: PlanResult?) {
            lastResult = result
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            gestureDetector.onTouchEvent(event)
            return true
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            for (obj in syntheticObjects) {
                val paint = if (obj.type == ObjectClass.BOMB) bombPaint else fruitPaint
                canvas.drawCircle(obj.x, obj.y, 24f, paint)
            }
            val result = lastResult
            if (result is PlanResult.Planned) {
                val waypoints = result.path.waypoints
                for (i in 1 until waypoints.size) {
                    canvas.drawLine(waypoints[i - 1].x, waypoints[i - 1].y, waypoints[i].x, waypoints[i].y, pathPaint)
                }
            }
        }
    }
}

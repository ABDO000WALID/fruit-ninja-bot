package com.example.fruitninjabot

import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.abs

/**
 * A focused calibration screen: the user drags the top-left and bottom-right handles of a
 * rectangle over their own screen (this activity is shown fullscreen, on top of nothing in
 * particular — the user is expected to remember roughly where the game's play area is, or to
 * switch to Fruit Ninja first and back, since this app cannot legally screenshot another app's
 * content without MediaProjection actively running).
 *
 * Saves the resulting rectangle as ROI fractions (0f..1f of screen width/height) via
 * [com.example.fruitninjabot.settings.SettingsRepository], so it stays valid across the POCO X7
 * Pro's screen resolution and after any rotation.
 */
class RoiCalibrationActivity : AppCompatActivity() {

    private lateinit var overlayView: RoiOverlayView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = FrameLayout(this)
        val settings = (application as FruitNinjaBotApp).settingsRepository
        val initialRoi = settings.currentRoi()

        overlayView = RoiOverlayView(this, initialRoi.leftFrac, initialRoi.topFrac, initialRoi.rightFrac, initialRoi.bottomFrac)
        root.addView(overlayView, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val instructions = TextView(this).apply {
            text = "Drag the corners to match the Fruit Ninja play area, excluding the status bar and any UI buttons. This is your Region Of Interest."
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#AA000000"))
            setPadding(24, 24, 24, 24)
        }
        root.addView(
            instructions,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                gravity = android.view.Gravity.TOP
            }
        )

        val saveButton = Button(this).apply {
            text = "Save ROI"
            setOnClickListener {
                val (l, t, r, b) = overlayView.currentFractions()
                (application as FruitNinjaBotApp).botController.saveRoiFraction(l, t, r, b)
                setResult(Activity.RESULT_OK)
                finish()
            }
        }
        root.addView(
            saveButton,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                gravity = android.view.Gravity.BOTTOM or android.view.Gravity.CENTER_HORIZONTAL
                bottomMargin = 48
            }
        )

        val cancelButton = Button(this).apply {
            text = "Cancel"
            setOnClickListener {
                setResult(Activity.RESULT_CANCELED)
                finish()
            }
        }
        root.addView(
            cancelButton,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                gravity = android.view.Gravity.BOTTOM or android.view.Gravity.START
                bottomMargin = 48
                leftMargin = 32
            }
        )

        setContentView(root)
    }

    /** Simple two-handle draggable rectangle drawn over a dimmed background. */
    private class RoiOverlayView(
        context: Context,
        initialLeftFrac: Float,
        initialTopFrac: Float,
        initialRightFrac: Float,
        initialBottomFrac: Float
    ) : View(context) {

        private var leftFrac = initialLeftFrac
        private var topFrac = initialTopFrac
        private var rightFrac = initialRightFrac
        private var bottomFrac = initialBottomFrac

        private var draggingHandle = Handle.NONE

        private val dimPaint = Paint().apply { color = Color.parseColor("#99000000") }
        private val rectPaint = Paint().apply {
            color = Color.parseColor("#FF2979FF"); style = Paint.Style.STROKE; strokeWidth = 6f
        }
        private val handlePaint = Paint().apply { color = Color.parseColor("#FF2979FF"); style = Paint.Style.FILL }

        private enum class Handle { NONE, TOP_LEFT, BOTTOM_RIGHT }

        fun currentFractions(): List<Float> = listOf(leftFrac, topFrac, rightFrac, bottomFrac)

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val left = leftFrac * width
            val top = topFrac * height
            val right = rightFrac * width
            val bottom = bottomFrac * height

            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), dimPaint)
            canvas.drawRect(left, top, right, bottom, rectPaint)
            canvas.drawCircle(left, top, HANDLE_RADIUS, handlePaint)
            canvas.drawCircle(right, bottom, HANDLE_RADIUS, handlePaint)
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            val x = event.x
            val y = event.y
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    val leftPx = leftFrac * width
                    val topPx = topFrac * height
                    val rightPx = rightFrac * width
                    val bottomPx = bottomFrac * height
                    draggingHandle = when {
                        abs(x - leftPx) < TOUCH_SLOP && abs(y - topPx) < TOUCH_SLOP -> Handle.TOP_LEFT
                        abs(x - rightPx) < TOUCH_SLOP && abs(y - bottomPx) < TOUCH_SLOP -> Handle.BOTTOM_RIGHT
                        else -> Handle.NONE
                    }
                }
                MotionEvent.ACTION_MOVE -> {
                    when (draggingHandle) {
                        Handle.TOP_LEFT -> {
                            leftFrac = (x / width).coerceIn(0f, rightFrac - 0.05f)
                            topFrac = (y / height).coerceIn(0f, bottomFrac - 0.05f)
                        }
                        Handle.BOTTOM_RIGHT -> {
                            rightFrac = (x / width).coerceIn(leftFrac + 0.05f, 1f)
                            bottomFrac = (y / height).coerceIn(topFrac + 0.05f, 1f)
                        }
                        Handle.NONE -> return false
                    }
                    invalidate()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    draggingHandle = Handle.NONE
                }
            }
            return true
        }

        companion object {
            private const val HANDLE_RADIUS = 28f
            private const val TOUCH_SLOP = 80f
        }
    }
}

package com.example.fruitninjabot.util

import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** A simple 2D point, used to keep geometry helpers free of any Android framework dependency. */
data class Point(val x: Float, val y: Float)

/** A normalized Region Of Interest, expressed as fractions (0f..1f) of the full screen. */
data class NormalizedRoi(
    val leftFrac: Float,
    val topFrac: Float,
    val rightFrac: Float,
    val bottomFrac: Float
) {
    init {
        require(leftFrac in 0f..1f) { "leftFrac out of range: $leftFrac" }
        require(topFrac in 0f..1f) { "topFrac out of range: $topFrac" }
        require(rightFrac in 0f..1f) { "rightFrac out of range: $rightFrac" }
        require(bottomFrac in 0f..1f) { "bottomFrac out of range: $bottomFrac" }
        require(rightFrac > leftFrac) { "rightFrac must be greater than leftFrac" }
        require(bottomFrac > topFrac) { "bottomFrac must be greater than topFrac" }
    }

    /** Converts this normalized ROI to absolute pixel coordinates for a screen of the given size. */
    fun toPixelRect(screenWidth: Int, screenHeight: Int): PixelRect {
        return PixelRect(
            left = (leftFrac * screenWidth).toInt(),
            top = (topFrac * screenHeight).toInt(),
            right = (rightFrac * screenWidth).toInt(),
            bottom = (bottomFrac * screenHeight).toInt()
        )
    }

    companion object {
        /**
         * A sensible default ROI that excludes a status-bar-sized strip at the top and a
         * navigation-bar-sized strip at the bottom, keeping the full width. This is a starting
         * point only — [SettingsRepository][com.example.fruitninjabot.settings.SettingsRepository]
         * persists the user's calibrated ROI once they've adjusted it.
         */
        fun defaultForGameplay(): NormalizedRoi = NormalizedRoi(
            leftFrac = 0f,
            topFrac = 0.08f,
            rightFrac = 1f,
            bottomFrac = 0.90f
        )
    }
}

data class PixelRect(val left: Int, val top: Int, val right: Int, val bottom: Int) {
    val width: Int get() = right - left
    val height: Int get() = bottom - top
}

object Geometry {

    fun distance(x1: Float, y1: Float, x2: Float, y2: Float): Float {
        val dx = x2 - x1
        val dy = y2 - y1
        return sqrt(dx * dx + dy * dy)
    }

    fun distance(a: Point, b: Point): Float = distance(a.x, a.y, b.x, b.y)

    /**
     * Shortest distance from point [p] to the line segment [a]-[b]. Used for bomb-safety-radius
     * checks against a proposed swipe path segment.
     */
    fun distancePointToSegment(p: Point, a: Point, b: Point): Float {
        val abx = b.x - a.x
        val aby = b.y - a.y
        val lengthSquared = abx * abx + aby * aby
        if (lengthSquared <= 1e-6f) {
            return distance(p, a)
        }
        var t = ((p.x - a.x) * abx + (p.y - a.y) * aby) / lengthSquared
        t = max(0f, min(1f, t))
        val projX = a.x + t * abx
        val projY = a.y + t * aby
        return distance(p.x, p.y, projX, projY)
    }

    /**
     * True if the circle centered at [center] with [radius] intersects the segment [a]-[b].
     * This is the core bomb-avoidance check: a proposed swipe segment must not come within the
     * configured safety radius of any bomb's (possibly predicted) position.
     */
    fun segmentIntersectsCircle(a: Point, b: Point, center: Point, radius: Float): Boolean {
        return distancePointToSegment(center, a, b) <= radius
    }

    /**
     * Normalizes an absolute pixel point into ROI-relative fractional coordinates (0f..1f),
     * clamped to the ROI bounds. Useful for stability checks that shouldn't depend on absolute
     * screen resolution.
     */
    fun normalizeToRoi(x: Float, y: Float, roi: PixelRect): Point {
        if (roi.width <= 0 || roi.height <= 0) return Point(0f, 0f)
        val fx = ((x - roi.left) / roi.width).coerceIn(0f, 1f)
        val fy = ((y - roi.top) / roi.height).coerceIn(0f, 1f)
        return Point(fx, fy)
    }
}

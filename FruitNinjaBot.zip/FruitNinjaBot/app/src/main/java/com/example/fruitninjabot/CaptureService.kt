package com.example.fruitninjabot

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.example.fruitninjabot.util.PixelRect
import kotlin.math.max

/**
 * Foreground service that owns the entire MediaProjection screen-capture pipeline: it obtains
 * the [MediaProjection], drives an [ImageReader]-backed [VirtualDisplay], converts frames to
 * [Bitmap]s cropped to the configured Region Of Interest, throttles to the configured FPS, and
 * hands finished frames to whichever [FrameListener] is currently registered (normally
 * [BotController]).
 *
 * Frames are never written to disk. Each [android.media.Image] is closed as soon as its pixels
 * have been copied into a reused [Bitmap], and no frame is retained longer than it takes to hand
 * it to the listener.
 */
class CaptureService : Service() {

    interface FrameListener {
        /** [bitmap] is owned by the service and reused across calls — do not recycle it, and do
         * not hold a reference to it past the end of this callback. Copy anything you need. */
        fun onFrame(bitmap: Bitmap, timestampMillis: Long)
        fun onCaptureError(message: String)
        fun onCaptureStopped()
    }

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var processingThread: HandlerThread? = null
    private var processingHandler: Handler? = null

    private var reusableBitmap: Bitmap? = null
    private var lastFrameProcessedAtMillis: Long = 0L
    private var targetFrameIntervalMillis: Long = 1000L / SettingsDefaults.FPS
    private var currentRoi: PixelRect? = null
    private var screenWidth: Int = 0
    private var screenHeight: Int = 0
    private var screenDensity: Int = 0

    private val mediaProjectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            Log.i(TAG, "MediaProjection stopped by the system/user")
            stopCaptureInternal(notifyListener = true)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
                val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
                    intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(EXTRA_RESULT_DATA)
                }
                val fps = intent.getIntExtra(EXTRA_FPS, SettingsDefaults.FPS)
                startForegroundNotification()
                if (data == null || resultCode == 0) {
                    listener?.onCaptureError("Missing MediaProjection permission result")
                    stopSelf()
                } else {
                    beginCapture(resultCode, data, fps)
                }
            }
            ACTION_STOP -> {
                stopCaptureInternal(notifyListener = true)
                stopSelf()
            }
            ACTION_UPDATE_ROI -> {
                val left = intent.getIntExtra(EXTRA_ROI_LEFT, 0)
                val top = intent.getIntExtra(EXTRA_ROI_TOP, 0)
                val right = intent.getIntExtra(EXTRA_ROI_RIGHT, screenWidth)
                val bottom = intent.getIntExtra(EXTRA_ROI_BOTTOM, screenHeight)
                currentRoi = PixelRect(left, top, right, bottom)
            }
            ACTION_UPDATE_FPS -> {
                val fps = intent.getIntExtra(EXTRA_FPS, SettingsDefaults.FPS).coerceIn(1, 60)
                targetFrameIntervalMillis = 1000L / fps
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        stopCaptureInternal(notifyListener = false)
        super.onDestroy()
    }

    private fun startForegroundNotification() {
        val openAppIntent = packageManager.getLaunchIntentForPackage(packageName)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, openAppIntent,
            PendingIntent.FLAG_IMMUTABLE
        )
        val notification: Notification = NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
            .setContentTitle(getString(R.string.notif_capture_title))
            .setContentText(getString(R.string.notif_capture_text))
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ServiceCompat.startForeground(
                this,
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun beginCapture(resultCode: Int, data: Intent, fps: Int) {
        targetFrameIntervalMillis = 1000L / fps.coerceIn(1, 60)

        val projectionManager =
            getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val projection = try {
            projectionManager.getMediaProjection(resultCode, data)
        } catch (e: SecurityException) {
            listener?.onCaptureError("MediaProjection permission was not granted: ${e.message}")
            stopSelf()
            return
        }

        if (projection == null) {
            listener?.onCaptureError("Failed to obtain MediaProjection")
            stopSelf()
            return
        }
        mediaProjection = projection

        val thread = HandlerThread("CaptureFrameThread").also { it.start() }
        processingThread = thread
        processingHandler = Handler(thread.looper)

        // registerCallback is mandatory as of Android 14 before creating the VirtualDisplay.
        projection.registerCallback(mediaProjectionCallback, processingHandler)

        setUpVirtualDisplay(projection)
    }

    private fun setUpVirtualDisplay(projection: MediaProjection) {
        val metrics = DisplayMetrics()
        val windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)

        screenWidth = metrics.widthPixels
        screenHeight = metrics.heightPixels
        screenDensity = metrics.densityDpi

        if (currentRoi == null) {
            // Default ROI mirrors NormalizedRoi.defaultForGameplay() until MainActivity sends a
            // saved/calibrated ROI via ACTION_UPDATE_ROI.
            currentRoi = PixelRect(
                left = 0,
                top = (screenHeight * 0.08f).toInt(),
                right = screenWidth,
                bottom = (screenHeight * 0.90f).toInt()
            )
        }

        val reader = ImageReader.newInstance(
            screenWidth,
            screenHeight,
            PixelFormat.RGBA_8888,
            2
        )
        imageReader = reader

        reader.setOnImageAvailableListener({ imageReader ->
            val image = try {
                imageReader.acquireLatestImage()
            } catch (e: IllegalStateException) {
                null
            } ?: return@setOnImageAvailableListener

            try {
                val now = android.os.SystemClock.elapsedRealtime()
                if (now - lastFrameProcessedAtMillis < targetFrameIntervalMillis) {
                    // Frame throttling: drop this frame, we're ahead of the configured FPS.
                    return@setOnImageAvailableListener
                }
                lastFrameProcessedAtMillis = now

                val bitmap = imageToBitmap(image) ?: return@setOnImageAvailableListener
                val roi = currentRoi
                val frameToDeliver = if (roi != null && roi.width > 0 && roi.height > 0) {
                    cropToRoi(bitmap, roi)
                } else {
                    bitmap
                }
                listener?.onFrame(frameToDeliver, now)
            } catch (t: Throwable) {
                Log.e(TAG, "Error processing frame", t)
                listener?.onCaptureError("Frame processing error: ${t.message}")
            } finally {
                image.close()
            }
        }, processingHandler)

        virtualDisplay = projection.createVirtualDisplay(
            "FruitNinjaBotCapture",
            screenWidth,
            screenHeight,
            screenDensity,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface,
            object : VirtualDisplay.Callback() {
                override fun onStopped() {
                    Log.i(TAG, "VirtualDisplay stopped")
                }
            },
            processingHandler
        )

        isCaptureActive = true
    }

    /** Converts the latest [android.media.Image] to a [Bitmap], reusing the backing bitmap
     * across frames to avoid a per-frame allocation storm. */
    private fun imageToBitmap(image: android.media.Image): Bitmap? {
        val plane = image.planes.getOrNull(0) ?: return null
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * image.width

        val requiredWidth = image.width + rowPadding / pixelStride
        val bmp = reusableBitmap.let {
            if (it != null && it.width == requiredWidth && it.height == image.height) {
                it
            } else {
                it?.recycle()
                Bitmap.createBitmap(requiredWidth, image.height, Bitmap.Config.ARGB_8888).also { newBmp ->
                    reusableBitmap = newBmp
                }
            }
        }
        buffer.rewind()
        bmp.copyPixelsFromBuffer(buffer)

        return if (requiredWidth != image.width) {
            // Crop off the row padding introduced by the stride so downstream ROI math is in
            // real screen pixels. This allocates a small bitmap only when the device's stride
            // requires it (common on some GPUs); most frames take the fast path above.
            Bitmap.createBitmap(bmp, 0, 0, image.width, image.height)
        } else {
            bmp
        }
    }

    private fun cropToRoi(bitmap: Bitmap, roi: PixelRect): Bitmap {
        val left = roi.left.coerceIn(0, bitmap.width - 1)
        val top = roi.top.coerceIn(0, bitmap.height - 1)
        val width = max(1, roi.width.coerceAtMost(bitmap.width - left))
        val height = max(1, roi.height.coerceAtMost(bitmap.height - top))
        return Bitmap.createBitmap(bitmap, left, top, width, height)
    }

    private fun stopCaptureInternal(notifyListener: Boolean) {
        isCaptureActive = false
        try {
            imageReader?.setOnImageAvailableListener(null, null)
            imageReader?.close()
        } catch (_: Exception) { }
        imageReader = null

        try {
            virtualDisplay?.release()
        } catch (_: Exception) { }
        virtualDisplay = null

        try {
            mediaProjection?.unregisterCallback(mediaProjectionCallback)
            mediaProjection?.stop()
        } catch (_: Exception) { }
        mediaProjection = null

        processingThread?.quitSafely()
        processingThread = null
        processingHandler = null

        reusableBitmap?.recycle()
        reusableBitmap = null

        if (notifyListener) {
            listener?.onCaptureStopped()
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                NOTIFICATION_CHANNEL_ID,
                getString(R.string.notif_channel_capture),
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    object SettingsDefaults {
        const val FPS = 15
    }

    companion object {
        private const val TAG = "CaptureService"
        private const val NOTIFICATION_CHANNEL_ID = "capture_channel"
        private const val NOTIFICATION_ID = 42

        const val ACTION_START = "com.example.fruitninjabot.action.START_CAPTURE"
        const val ACTION_STOP = "com.example.fruitninjabot.action.STOP_CAPTURE"
        const val ACTION_UPDATE_ROI = "com.example.fruitninjabot.action.UPDATE_ROI"
        const val ACTION_UPDATE_FPS = "com.example.fruitninjabot.action.UPDATE_FPS"

        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"
        const val EXTRA_FPS = "extra_fps"
        const val EXTRA_ROI_LEFT = "extra_roi_left"
        const val EXTRA_ROI_TOP = "extra_roi_top"
        const val EXTRA_ROI_RIGHT = "extra_roi_right"
        const val EXTRA_ROI_BOTTOM = "extra_roi_bottom"

        @Volatile
        var listener: FrameListener? = null

        @Volatile
        var isCaptureActive: Boolean = false
            private set
    }
}

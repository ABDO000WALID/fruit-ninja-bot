package com.example.fruitninjabot.overlay

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import com.example.fruitninjabot.detection.ObjectClass
import com.example.fruitninjabot.util.Point

/**
 * Optional, disabled-by-default overlay window that draws:
 *  - GREEN boxes around detected fruit
 *  - RED boxes around detected bombs (plus their safety radius)
 *  - YELLOW dots for predicted positions
 *  - BLUE lines for the currently planned swipe path
 *
 * The overlay is a `TYPE_APPLICATION_OVERLAY` window that is explicitly non-touchable and
 * non-focusable, so it never intercepts input meant for the game and never draws over system
 * status bar / navigation bar content (those regions are owned by the system UI layer, above
 * this app-level overlay window, and this view only ever draws within the app's own bounds
 * offset to the calibrated ROI).
 *
 * Requires the user to have granted "Draw over other apps" (SYSTEM_ALERT_WINDOW /
 * `Settings.canDrawOverlays`) — MainActivity checks and requests this before starting the
 * service, and the service itself will simply fail to add its window (and stop) if permission is
 * missing, rather than crash.
 */
class DebugOverlayService : Service() {

    private var windowManager: WindowManager? = null
    private var overlayView: OverlayView? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        windowManager = wm

        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(metrics)

        val view = OverlayView(this)
        overlayView = view

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            metrics.widthPixels,
            metrics.heightPixels,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START

        try {
            wm.addView(view, params)
            activeView = view
        } catch (e: Exception) {
            // Most commonly: SYSTEM_ALERT_WINDOW permission not granted. Fail safe instead of
            // crashing the whole bot.
            stopSelf()
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        overlayView?.invalidate()
    }

    override fun onDestroy() {
        val wm = windowManager
        val view = overlayView
        if (wm != null && view != null) {
            try {
                wm.removeView(view)
            } catch (_: Exception) { }
        }
        overlayView = null
        windowManager = null
        activeView = null
        super.onDestroy()
    }

    /** A single box to draw, in full-screen pixel coordinates (already ROI-offset). */
    data class OverlayBox(val left: Float, val top: Float, val right: Float, val bottom: Float, val type: ObjectClass)

    /** A predicted point to draw, in full-screen pixel coordinates. */
    data class OverlayPredictedPoint(val x: Float, val y: Float)

    private class OverlayView(context: Context) : View(context) {
        private val fruitPaint = Paint().apply {
            color = Color.parseColor("#FF00E676"); style = Paint.Style.STROKE; strokeWidth = 4f
        }
        private val bombPaint = Paint().apply {
            color = Color.parseColor("#FFFF1744"); style = Paint.Style.STROKE; strokeWidth = 4f
        }
        private val predictedPaint = Paint().apply {
            color = Color.parseColor("#FFFFEA00"); style = Paint.Style.FILL
        }
        private val pathPaint = Paint().apply {
            color = Color.parseColor("#FF2979FF"); style = Paint.Style.STROKE; strokeWidth = 6f
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val boxes = currentBoxes
            val predicted = currentPredicted
            val paths = currentPaths

            if (showDetectedObjects) {
                for (box in boxes) {
                    val paint = if (box.type == ObjectClass.BOMB) bombPaint else fruitPaint
                    canvas.drawRect(box.left, box.top, box.right, box.bottom, paint)
                }
                for (p in predicted) {
                    canvas.drawCircle(p.x, p.y, 8f, predictedPaint)
                }
            }
            if (showPredictedPaths) {
                for (path in paths) {
                    for (i in 1 until path.size) {
                        canvas.drawLine(path[i - 1].x, path[i - 1].y, path[i].x, path[i].y, pathPaint)
                    }
                }
            }
        }
    }

    companion object {
        @Volatile var showDetectedObjects: Boolean = true
        @Volatile var showPredictedPaths: Boolean = true

        @Volatile private var currentBoxes: List<OverlayBox> = emptyList()
        @Volatile private var currentPredicted: List<OverlayPredictedPoint> = emptyList()
        @Volatile private var currentPaths: List<List<Point>> = emptyList()

        @Volatile var activeView: OverlayView? = null

        /** Called from BotController after each analyze+plan cycle. Safe to call from any thread. */
        fun updateOverlayData(
            boxes: List<OverlayBox>,
            predicted: List<OverlayPredictedPoint>,
            paths: List<List<Point>>
        ) {
            currentBoxes = boxes
            currentPredicted = predicted
            currentPaths = paths
            activeView?.postInvalidate()
        }
    }
}

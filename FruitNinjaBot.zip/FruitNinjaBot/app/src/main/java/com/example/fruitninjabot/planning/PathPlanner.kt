package com.example.fruitninjabot.planning

import com.example.fruitninjabot.tracking.TrackedObject

/**
 * Turns the current set of tracked fruits/bombs into either a safe [SwipePath] or a documented
 * rejection. Implementations must never return a path that intersects a bomb's safety zone —
 * see [SafeSwipePlanner] for the concrete bomb-avoidance + combo logic.
 */
interface PathPlanner {

    /**
     * @param trackedObjects all currently live tracked objects (fruits and bombs together).
     * @param predictionHorizonMillis how far into the future to project object positions before
     *   planning, to compensate for detection + gesture dispatch latency.
     * @param nowMillis current timestamp, same clock as [TrackedObject.lastSeen].
     */
    fun plan(
        trackedObjects: List<TrackedObject>,
        predictionHorizonMillis: Long,
        nowMillis: Long
    ): PlanResult
}

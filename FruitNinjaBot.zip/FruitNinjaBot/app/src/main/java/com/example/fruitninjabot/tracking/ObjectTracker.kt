package com.example.fruitninjabot.tracking

import com.example.fruitninjabot.detection.DetectedObject
import kotlin.math.hypot

/**
 * A lightweight, non-ML multi-object tracker.
 *
 * Each call to [update] performs greedy nearest-neighbor matching between the previous frame's
 * tracked objects and the newly detected objects of the same [com.example.fruitninjabot.detection.ObjectClass],
 * within [maxMatchDistancePx]. Matched objects get an updated velocity estimate (simple
 * finite-difference, optionally smoothed with [velocitySmoothing]); unmatched detections become
 * new tracks; tracks that go unmatched for more than [maxMissedFrames] are dropped.
 *
 * This intentionally avoids any heavy ML dependency (no Kalman filter library, no learned motion
 * model) — Fruit Ninja fruits move in short, fast, mostly-ballistic arcs over only a handful of
 * frames before being sliced or leaving the screen, so a simple linear velocity estimate is
 * sufficient for short-horizon prediction.
 */
class ObjectTracker(
    private val maxMatchDistancePx: Float = 90f,
    private val maxMissedFrames: Int = 3,
    private val velocitySmoothing: Float = 0.5f
) {
    private var nextId = 1
    private val tracks = LinkedHashMap<Int, MutableTrackState>()

    private data class MutableTrackState(
        var id: Int,
        var type: com.example.fruitninjabot.detection.ObjectClass,
        var x: Float,
        var y: Float,
        var vx: Float,
        var vy: Float,
        var confidence: Float,
        var lastSeen: Long,
        var hitStreak: Int,
        var missedFrames: Int
    )

    /**
     * Feed a new frame's detections in. Returns the current set of live tracked objects
     * (including ones not matched this frame but still within [maxMissedFrames]).
     */
    fun update(detections: List<DetectedObject>, timestamp: Long): List<TrackedObject> {
        val unmatchedDetections = detections.toMutableList()
        val matchedTrackIds = HashSet<Int>()

        // Greedy nearest-neighbor: for each existing track, find the closest same-class
        // detection within range that hasn't already been claimed this frame.
        for (track in tracks.values.sortedBy { it.id }) {
            var bestIndex = -1
            var bestDist = Float.MAX_VALUE
            for ((index, det) in unmatchedDetections.withIndex()) {
                if (det.type != track.type) continue
                val dist = hypot((det.centerX - track.x).toDouble(), (det.centerY - track.y).toDouble()).toFloat()
                if (dist < bestDist && dist <= maxMatchDistancePx) {
                    bestDist = dist
                    bestIndex = index
                }
            }

            if (bestIndex >= 0) {
                val det = unmatchedDetections.removeAt(bestIndex)
                val dt = (timestamp - track.lastSeen).coerceAtLeast(1L)
                val instantVx = (det.centerX - track.x) / dt
                val instantVy = (det.centerY - track.y) / dt

                track.vx = track.vx * velocitySmoothing + instantVx * (1 - velocitySmoothing)
                track.vy = track.vy * velocitySmoothing + instantVy * (1 - velocitySmoothing)
                track.x = det.centerX
                track.y = det.centerY
                track.confidence = det.confidence
                track.lastSeen = timestamp
                track.hitStreak += 1
                track.missedFrames = 0
                matchedTrackIds.add(track.id)
            } else {
                track.missedFrames += 1
            }
        }

        // Any detection nobody claimed starts a brand new track.
        for (det in unmatchedDetections) {
            val id = nextId++
            tracks[id] = MutableTrackState(
                id = id,
                type = det.type,
                x = det.centerX,
                y = det.centerY,
                vx = 0f,
                vy = 0f,
                confidence = det.confidence,
                lastSeen = timestamp,
                hitStreak = 1,
                missedFrames = 0
            )
        }

        // Drop stale tracks.
        val toRemove = tracks.values.filter { it.missedFrames > maxMissedFrames }.map { it.id }
        toRemove.forEach { tracks.remove(it) }

        return tracks.values.map {
            TrackedObject(
                id = it.id,
                type = it.type,
                x = it.x,
                y = it.y,
                vx = it.vx,
                vy = it.vy,
                confidence = it.confidence,
                lastSeen = it.lastSeen,
                hitStreak = it.hitStreak
            )
        }
    }

    /** Clears all track state. Call this when capture stops or the ROI/resolution changes. */
    fun reset() {
        tracks.clear()
        nextId = 1
    }
}

# Fruit Ninja Bot - ProGuard / R8 rules
# This project ships with minifyEnabled=false by default (see app/build.gradle.kts).
# These rules are provided in case the user enables minification later.

-keepattributes *Annotation*
-keepattributes SourceFile,LineNumberTable

# Keep data model classes used for detection/tracking/planning (reflection-free but kept
# defensively in case of future serialization).
-keep class com.example.fruitninjabot.detection.** { *; }
-keep class com.example.fruitninjabot.tracking.** { *; }
-keep class com.example.fruitninjabot.planning.** { *; }

# AccessibilityService and other manifest-declared components are kept by AGP automatically,
# but we keep them explicitly for safety.
-keep class com.example.fruitninjabot.BotAccessibilityService { *; }
-keep class com.example.fruitninjabot.CaptureService { *; }
-keep class com.example.fruitninjabot.overlay.DebugOverlayService { *; }

package com.example.fruitninjabot

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.os.SystemClock
import android.util.Log
import androidx.core.content.ContextCompat
import com.example.fruitninjabot.detection.ObjectClass
import com.example.fruitninjabot.detection.ObjectDetector
import com.example.fruitninjabot.detection.OpenCvObjectDetector
import com.example.fruitninjabot.overlay.DebugOverlayService
import com.example.fruitninjabot.planning.PlanResult
import com.example.fruitninjabot.planning.SafeSwipePlanner
import com.example.fruitninjabot.settings.SettingsRepository
import com.example.fruitninjabot.tracking.ObjectTracker
import com.example.fruitninjabot.util.Point

/**
 * The single object that owns the bot's state machine and wires together every other piece:
 * frames arrive from [CaptureService], get detected/tracked/planned, and — only when a safe plan
 * exists and the state machine allows it — a gesture is dispatched through
 * [BotAccessibilityService].
 *
 * Concurrency model: [onFrame] is invoked on [CaptureService]'s dedicated background handler
 * thread, never the main thread. All detection/tracking/planning work happens synchronously on
 * that same callback (which is fine — frames are already throttled to the configured FPS, so
 * there is no risk of starving the capture pipeline as long as processing stays well under the
 * frame interval). [statusListener] callbacks are marshalled back to the main thread by the
 * caller (MainActivity) via its own dispatcher; BotController itself does not touch any View.
 */
class BotController(
    private val appContext: Context,
    private val settings: SettingsRepository
) : CaptureService.FrameListener {

    interface StatusListener {
        fun onStatusUpdate(status: BotStatus)
    }

    @Volatile
    var statusListener: StatusListener? = null

    @Volatile
    private var state: BotState = BotState.STOPPED

    private var detector: ObjectDetector = OpenCvObjectDetector()
    private val tracker = ObjectTracker()
    private val planner = SafeSwipePlanner()

    private var roiLeftPx: Int = 0
    private var roiTopPx: Int = 0

    // Rolling FPS estimate over the last N processed frames.
    private val frameTimestamps = ArrayDeque<Long>()
    private var lastLatencyMillis: Long = 0L

    private var totalSwipes = 0
    private var successfulPlans = 0
    private var rejectedPlans = 0
    private var lastFruitCount = 0
    private var lastBombCount = 0
    private var lastError: String? = null

    // Simple cooldown so we don't try to plan a brand-new swipe while a gesture is still in
    // flight, and so a single frame of stale data can't trigger a duplicate swipe.
    private var lastSwipeDispatchedAtMillis = 0L
    private val minMillisBetweenSwipes = 60L

    fun currentState(): BotState = state

    /**
     * Starts the pipeline: begins screen capture (must already have the MediaProjection
     * permission result — see MainActivity's registerForActivityResult flow) and moves the
     * state machine to CAPTURING. Does NOT start swiping by itself — [startBot] is a separate,
     * explicit step, matching the "first launch should not automatically start swiping"
     * requirement.
     */
    fun startCapture(resultCode: Int, data: Intent) {
        if (state != BotState.STOPPED && state != BotState.ERROR) return
        setState(BotState.STARTING)

        CaptureService.listener = this

        val startIntent = Intent(appContext, CaptureService::class.java).apply {
            action = CaptureService.ACTION_START
            putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
            putExtra(CaptureService.EXTRA_RESULT_DATA, data)
            putExtra(CaptureService.EXTRA_FPS, settings.detectionFps)
        }
        ContextCompat.startForegroundService(appContext, startIntent)

        // CaptureService applies a sane default ROI immediately using its own screen metrics.
        // MainActivity resolves the user's saved fractional ROI (from `roi`) into exact pixel
        // coordinates using its own display metrics and calls updateRoiPixels() right after this
        // returns, refining the default.
        setState(BotState.CAPTURING)
        publishStatus()
    }

    fun stopCapture() {
        val stopIntent = Intent(appContext, CaptureService::class.java).apply {
            action = CaptureService.ACTION_STOP
        }
        appContext.startService(stopIntent)
        CaptureService.listener = null
        tracker.reset()
        detector.release()
        setState(BotState.STOPPED)
        publishStatus()
    }

    /** Explicit user action required before any gesture will ever be dispatched automatically. */
    fun startBot() {
        if (!BotAccessibilityService.isServiceRunning()) {
            lastError = "Accessibility service is not enabled"
            setState(BotState.ERROR)
            publishStatus()
            return
        }
        if (!CaptureService.isCaptureActive) {
            lastError = "Screen capture is not active"
            setState(BotState.ERROR)
            publishStatus()
            return
        }
        lastError = null
        setState(BotState.CAPTURING)
        botRunning = true
        publishStatus()
    }

    fun pauseBot() {
        botRunning = false
        setState(BotState.PAUSED)
        publishStatus()
    }

    fun resumeBot() {
        if (state == BotState.PAUSED) {
            botRunning = true
            setState(BotState.CAPTURING)
            publishStatus()
        }
    }

    fun stopBot() {
        botRunning = false
        stopCapture()
    }

    @Volatile
    private var botRunning = false

    /**
     * Performs one small, fixed, pre-planned swipe near the center of the screen so the user can
     * confirm gestures actually work before trusting the bot to play automatically. Bypasses
     * detection entirely — it is intentionally not routed through [SafeSwipePlanner] because
     * there is nothing to avoid in a blank test swipe, but it still goes through the same
     * single-gesture-at-a-time guard in [BotAccessibilityService].
     */
    fun performTestSwipe(screenWidthPx: Int, screenHeightPx: Int, onResult: (Boolean) -> Unit) {
        val service = BotAccessibilityService.getInstance()
        if (service == null) {
            onResult(false)
            return
        }
        val centerX = screenWidthPx / 2f
        val centerY = screenHeightPx / 2f
        val waypoints = listOf(
            Point(centerX - 150f, centerY + 150f),
            Point(centerX, centerY),
            Point(centerX + 150f, centerY - 150f)
        )
        service.performSwipe(waypoints, settings.swipeDurationMillis) { success ->
            if (success) totalSwipes++
            publishStatus()
            onResult(success)
        }
    }

    /** Persists the user's calibrated ROI as fractions of screen size (resolution-independent). */
    fun saveRoiFraction(leftFrac: Float, topFrac: Float, rightFrac: Float, bottomFrac: Float) {
        settings.roiLeftFrac = leftFrac
        settings.roiTopFrac = topFrac
        settings.roiRightFrac = rightFrac
        settings.roiBottomFrac = bottomFrac
    }

    /** Called by MainActivity once it knows real screen pixel dimensions, to push an exact ROI. */
    fun updateRoiPixels(left: Int, top: Int, right: Int, bottom: Int) {
        roiLeftPx = left
        roiTopPx = top
        val intent = Intent(appContext, CaptureService::class.java).apply {
            action = CaptureService.ACTION_UPDATE_ROI
            putExtra(CaptureService.EXTRA_ROI_LEFT, left)
            putExtra(CaptureService.EXTRA_ROI_TOP, top)
            putExtra(CaptureService.EXTRA_ROI_RIGHT, right)
            putExtra(CaptureService.EXTRA_ROI_BOTTOM, bottom)
        }
        appContext.startService(intent)
    }

    fun updateFps(fps: Int) {
        settings.detectionFps = fps
        val intent = Intent(appContext, CaptureService::class.java).apply {
            action = CaptureService.ACTION_UPDATE_FPS
            putExtra(CaptureService.EXTRA_FPS, fps)
        }
        if (CaptureService.isCaptureActive) appContext.startService(intent)
    }

    // ---- CaptureService.FrameListener --------------------------------------------------

    override fun onFrame(bitmap: Bitmap, timestampMillis: Long) {
        if (!botRunning) {
            // Capture can be active (for preview/calibration) even while the bot isn't playing.
            return
        }
        if (state == BotState.PAUSED || state == BotState.ERROR) return

        val frameStart = SystemClock.elapsedRealtime()
        recordFrameForFps(frameStart)

        try {
            setState(BotState.ANALYZING)
            val detections = detector.detect(bitmap, timestampMillis)
            lastFruitCount = detections.count { it.type == ObjectClass.FRUIT }
            lastBombCount = detections.count { it.type == ObjectClass.BOMB }

            val tracked = tracker.update(detections, timestampMillis)

            setState(BotState.PLANNING)
            val plannerConfig = SafeSwipePlanner.PlannerConfig(
                minFruitConfidence = settings.minConfidence,
                bombSafetyRadiusPx = settings.bombSafetyRadiusPx,
                swipeDurationMillis = settings.swipeDurationMillis,
                maxFruitsPerSwipe = settings.maxFruitsPerSwipe,
                comboModeEnabled = settings.comboModeEnabled
            )
            planner.updateConfig(plannerConfig)

            val predictionHorizon = 80L // ms, compensates for detect+plan+dispatch latency
            val result = planner.plan(tracked, predictionHorizon, timestampMillis)

            if (settings.debugOverlayEnabled) {
                publishOverlay(detections, result)
            }

            when (result) {
                is PlanResult.Planned -> {
                    successfulPlans++
                    maybeDispatchSwipe(result.path.waypoints, result.path.durationMillis)
                }
                is PlanResult.Rejected -> {
                    rejectedPlans++
                    Log.d(TAG, "Plan rejected: ${result.reason}")
                }
            }

            setState(BotState.CAPTURING)
        } catch (t: Throwable) {
            Log.e(TAG, "Error in frame pipeline", t)
            lastError = t.message
            setState(BotState.ERROR)
        } finally {
            lastLatencyMillis = SystemClock.elapsedRealtime() - frameStart
            publishStatus()
        }
    }

    override fun onCaptureError(message: String) {
        lastError = message
        setState(BotState.ERROR)
        publishStatus()
    }

    override fun onCaptureStopped() {
        botRunning = false
        setState(BotState.STOPPED)
        publishStatus()
    }

    // ---- internal helpers -----------------------------------------------------------------

    private fun maybeDispatchSwipe(roiRelativeWaypoints: List<Point>, durationMillis: Long) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastSwipeDispatchedAtMillis < minMillisBetweenSwipes) return

        val service = BotAccessibilityService.getInstance() ?: run {
            lastError = "Accessibility service unavailable at swipe time"
            setState(BotState.ERROR)
            return
        }
        if (service.isBusy()) return

        // Offset ROI-relative coordinates into full-screen coordinates for the actual gesture.
        val fullScreenWaypoints = roiRelativeWaypoints.map { Point(it.x + roiLeftPx, it.y + roiTopPx) }

        setState(BotState.SWIPING)
        lastSwipeDispatchedAtMillis = now
        service.performSwipe(fullScreenWaypoints, durationMillis) { success ->
            if (success) totalSwipes++
            if (state == BotState.SWIPING) setState(BotState.CAPTURING)
            publishStatus()
        }
    }

    private fun publishOverlay(
        detections: List<com.example.fruitninjabot.detection.DetectedObject>,
        result: PlanResult
    ) {
        val boxes = detections.map {
            DebugOverlayService.OverlayBox(
                left = it.left + roiLeftPx,
                top = it.top + roiTopPx,
                right = it.right + roiLeftPx,
                bottom = it.bottom + roiTopPx,
                type = it.type
            )
        }
        val paths = when (result) {
            is PlanResult.Planned -> listOf(result.path.waypoints.map { Point(it.x + roiLeftPx, it.y + roiTopPx) })
            else -> emptyList()
        }
        DebugOverlayService.showDetectedObjects = settings.showDetectedObjects
        DebugOverlayService.showPredictedPaths = settings.showPredictedPaths
        DebugOverlayService.updateOverlayData(boxes, emptyList(), paths)
    }

    private fun recordFrameForFps(nowMillis: Long) {
        frameTimestamps.addLast(nowMillis)
        while (frameTimestamps.isNotEmpty() && nowMillis - frameTimestamps.first() > 2000L) {
            frameTimestamps.removeFirst()
        }
    }

    private fun currentFps(): Float {
        if (frameTimestamps.size < 2) return 0f
        val windowSeconds = (frameTimestamps.last() - frameTimestamps.first()) / 1000f
        if (windowSeconds <= 0f) return 0f
        return (frameTimestamps.size - 1) / windowSeconds
    }

    private fun setState(newState: BotState) {
        state = newState
    }

    private fun publishStatus() {
        statusListener?.onStatusUpdate(
            BotStatus(
                state = state,
                accessibilityEnabled = BotAccessibilityService.isServiceRunning(),
                captureActive = CaptureService.isCaptureActive,
                fps = currentFps(),
                latencyMillis = lastLatencyMillis,
                lastFruitCount = lastFruitCount,
                lastBombCount = lastBombCount,
                totalSwipes = totalSwipes,
                successfulPlans = successfulPlans,
                rejectedPlans = rejectedPlans,
                lastError = lastError
            )
        )
    }

    companion object {
        private const val TAG = "BotController"
    }
}

package com.example.fruitninjabot

enum class BotState {
    STOPPED,
    STARTING,
    CAPTURING,
    ANALYZING,
    PLANNING,
    SWIPING,
    PAUSED,
    ERROR
}

/**
 * Immutable snapshot of everything the UI needs to render, published by [BotController] on a
 * background-safe callback. Kept as a single object (rather than many LiveData fields) so the UI
 * always renders a self-consistent set of numbers instead of a torn mix of old/new counters.
 */
data class BotStatus(
    val state: BotState = BotState.STOPPED,
    val accessibilityEnabled: Boolean = false,
    val captureActive: Boolean = false,
    val fps: Float = 0f,
    val latencyMillis: Long = 0L,
    val lastFruitCount: Int = 0,
    val lastBombCount: Int = 0,
    val totalSwipes: Int = 0,
    val successfulPlans: Int = 0,
    val rejectedPlans: Int = 0,
    val lastError: String? = null
)

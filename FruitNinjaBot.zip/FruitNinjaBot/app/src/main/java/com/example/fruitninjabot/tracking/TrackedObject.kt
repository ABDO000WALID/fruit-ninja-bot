package com.example.fruitninjabot.tracking

import com.example.fruitninjabot.detection.ObjectClass

/**
 * A [com.example.fruitninjabot.detection.DetectedObject] that has been matched across frames by
 * [ObjectTracker], with an estimated velocity in pixels/millisecond.
 */
data class TrackedObject(
    val id: Int,
    val type: ObjectClass,
    val x: Float,
    val y: Float,
    val vx: Float,
    val vy: Float,
    val confidence: Float,
    val lastSeen: Long,
    /** Number of consecutive frames this id has been matched, used to gate confidence. */
    val hitStreak: Int
) {
    /**
     * Predicts this object's position [deltaMillis] into the future assuming constant velocity.
     * [vx] and [vy] are in pixels per millisecond, so this is a simple linear extrapolation.
     */
    fun predictPosition(deltaMillis: Long): Pair<Float, Float> {
        return (x + vx * deltaMillis) to (y + vy * deltaMillis)
    }
}

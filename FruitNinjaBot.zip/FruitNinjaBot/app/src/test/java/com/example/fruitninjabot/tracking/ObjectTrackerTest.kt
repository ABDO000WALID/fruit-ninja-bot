package com.example.fruitninjabot.tracking

import com.example.fruitninjabot.detection.DetectedObject
import com.example.fruitninjabot.detection.ObjectClass
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ObjectTrackerTest {

    private fun fruit(x: Float, y: Float, t: Long, confidence: Float = 0.8f) = DetectedObject(
        type = ObjectClass.FRUIT,
        centerX = x,
        centerY = y,
        width = 20f,
        height = 20f,
        confidence = confidence,
        timestamp = t
    )

    private fun bomb(x: Float, y: Float, t: Long) = DetectedObject(
        type = ObjectClass.BOMB,
        centerX = x,
        centerY = y,
        width = 20f,
        height = 20f,
        confidence = 0.9f,
        timestamp = t
    )

    @Test
    fun newDetection_createsNewTrack() {
        val tracker = ObjectTracker()
        val result = tracker.update(listOf(fruit(10f, 10f, 0L)), 0L)
        assertEquals(1, result.size)
        assertEquals(1, result[0].hitStreak)
    }

    @Test
    fun matchingDetectionAcrossFrames_keepsSameId() {
        val tracker = ObjectTracker()
        val first = tracker.update(listOf(fruit(10f, 10f, 0L)), 0L)
        val firstId = first[0].id

        val second = tracker.update(listOf(fruit(15f, 10f, 100L)), 100L)
        assertEquals(1, second.size)
        assertEquals(firstId, second[0].id)
        assertEquals(2, second[0].hitStreak)
    }

    @Test
    fun matchingDetection_estimatesPositiveVelocity() {
        val tracker = ObjectTracker()
        tracker.update(listOf(fruit(10f, 10f, 0L)), 0L)
        // Moves 50px right over 100ms => vx should be positive (~0.5 px/ms before smoothing).
        val second = tracker.update(listOf(fruit(60f, 10f, 100L)), 100L)
        assertTrue("expected positive vx, got ${second[0].vx}", second[0].vx > 0f)
    }

    @Test
    fun differentClasses_doNotMatchEachOther() {
        val tracker = ObjectTracker()
        tracker.update(listOf(fruit(10f, 10f, 0L)), 0L)
        // A bomb appearing at nearly the same spot must NOT be treated as the same track as the
        // fruit — mixing classes here would be a safety bug (a bomb could inherit a fruit's
        // "safe to hit" trajectory).
        val second = tracker.update(listOf(bomb(11f, 11f, 100L)), 100L)
        assertEquals(2, second.size)
        assertTrue(second.any { it.type == ObjectClass.FRUIT })
        assertTrue(second.any { it.type == ObjectClass.BOMB })
    }

    @Test
    fun farAwayDetection_doesNotMatch_createsNewTrack() {
        val tracker = ObjectTracker(maxMatchDistancePx = 50f)
        tracker.update(listOf(fruit(10f, 10f, 0L)), 0L)
        val second = tracker.update(listOf(fruit(500f, 500f, 100L)), 100L)
        // Old track persists (not yet past maxMissedFrames) and a new track is created for the
        // far-away detection.
        assertEquals(2, second.size)
    }

    @Test
    fun unmatchedTrack_isDroppedAfterMaxMissedFrames() {
        val tracker = ObjectTracker(maxMissedFrames = 2)
        tracker.update(listOf(fruit(10f, 10f, 0L)), 0L)
        tracker.update(emptyList(), 10L)
        tracker.update(emptyList(), 20L)
        val result = tracker.update(emptyList(), 30L)
        assertTrue(result.isEmpty())
    }

    @Test
    fun reset_clearsAllTracks() {
        val tracker = ObjectTracker()
        tracker.update(listOf(fruit(10f, 10f, 0L)), 0L)
        tracker.reset()
        val result = tracker.update(listOf(fruit(10f, 10f, 0L)), 0L)
        // After reset, ids restart from 1.
        assertEquals(1, result[0].id)
    }
}

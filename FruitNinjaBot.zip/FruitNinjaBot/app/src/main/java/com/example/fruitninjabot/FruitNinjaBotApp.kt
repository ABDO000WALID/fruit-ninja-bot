package com.example.fruitninjabot

import android.app.Application
import com.example.fruitninjabot.settings.SettingsRepository

class FruitNinjaBotApp : Application() {

    lateinit var settingsRepository: SettingsRepository
        private set

    lateinit var botController: BotController
        private set

    override fun onCreate() {
        super.onCreate()
        settingsRepository = SettingsRepository(this)
        botController = BotController(this, settingsRepository)
    }
}

package com.example.fruitninjabot.util

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GeometryTest {

    @Test
    fun distance_horizontalLine_isCorrect() {
        val d = Geometry.distance(0f, 0f, 3f, 4f)
        assertEquals(5f, d, 0.001f)
    }

    @Test
    fun distancePointToSegment_pointOnSegment_isZero() {
        val d = Geometry.distancePointToSegment(Point(5f, 0f), Point(0f, 0f), Point(10f, 0f))
        assertEquals(0f, d, 0.001f)
    }

    @Test
    fun distancePointToSegment_pointBeyondEndpoint_usesClosestEndpoint() {
        // Point is "past" b, so distance should be to b, not an extrapolated point on the line.
        val d = Geometry.distancePointToSegment(Point(20f, 0f), Point(0f, 0f), Point(10f, 0f))
        assertEquals(10f, d, 0.001f)
    }

    @Test
    fun distancePointToSegment_perpendicularOffset_isCorrect() {
        val d = Geometry.distancePointToSegment(Point(5f, 5f), Point(0f, 0f), Point(10f, 0f))
        assertEquals(5f, d, 0.001f)
    }

    @Test
    fun segmentIntersectsCircle_pathThroughCenter_isTrue() {
        val hit = Geometry.segmentIntersectsCircle(
            Point(0f, 0f), Point(100f, 0f), Point(50f, 0f), radius = 20f
        )
        assertTrue(hit)
    }

    @Test
    fun segmentIntersectsCircle_pathFarAway_isFalse() {
        val hit = Geometry.segmentIntersectsCircle(
            Point(0f, 0f), Point(100f, 0f), Point(50f, 500f), radius = 20f
        )
        assertFalse(hit)
    }

    @Test
    fun segmentIntersectsCircle_pathJustOutsideRadius_isFalse() {
        val hit = Geometry.segmentIntersectsCircle(
            Point(0f, 0f), Point(100f, 0f), Point(50f, 21f), radius = 20f
        )
        assertFalse(hit)
    }

    @Test
    fun segmentIntersectsCircle_pathJustInsideRadius_isTrue() {
        val hit = Geometry.segmentIntersectsCircle(
            Point(0f, 0f), Point(100f, 0f), Point(50f, 19f), radius = 20f
        )
        assertTrue(hit)
    }

    @Test
    fun normalizeToRoi_pointInsideRoi_mapsToUnitRange() {
        val roi = PixelRect(left = 100, top = 100, right = 300, bottom = 300)
        val p = Geometry.normalizeToRoi(200f, 200f, roi)
        assertEquals(0.5f, p.x, 0.001f)
        assertEquals(0.5f, p.y, 0.001f)
    }

    @Test
    fun normalizeToRoi_pointOutsideRoi_isClamped() {
        val roi = PixelRect(left = 100, top = 100, right = 300, bottom = 300)
        val p = Geometry.normalizeToRoi(-50f, 5000f, roi)
        assertEquals(0f, p.x, 0.001f)
        assertEquals(1f, p.y, 0.001f)
    }

    @Test(expected = IllegalArgumentException::class)
    fun normalizedRoi_invalidRange_throws() {
        NormalizedRoi(leftFrac = 0.5f, topFrac = 0f, rightFrac = 0.4f, bottomFrac = 1f)
    }

    @Test
    fun normalizedRoi_toPixelRect_scalesCorrectly() {
        val roi = NormalizedRoi(leftFrac = 0.1f, topFrac = 0.2f, rightFrac = 0.9f, bottomFrac = 0.8f)
        val px = roi.toPixelRect(1000, 2000)
        assertEquals(100, px.left)
        assertEquals(400, px.top)
        assertEquals(900, px.right)
        assertEquals(1600, px.bottom)
    }
}

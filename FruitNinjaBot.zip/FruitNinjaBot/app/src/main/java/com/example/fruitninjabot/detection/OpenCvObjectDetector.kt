package com.example.fruitninjabot.detection

import android.graphics.Bitmap
import android.graphics.Color

/**
 * A concrete [ObjectDetector] implementation.
 *
 * IMPORTANT NAMING NOTE: this class is named `OpenCvObjectDetector` to match the requested
 * architecture, but it does NOT link the native OpenCV Android SDK. Packaging the OpenCV AAR
 * reliably (correct ABI split, native .so size, Maven coordinate churn) is exactly the kind of
 * thing that can silently break a "download and build" project on a machine that doesn't have
 * the same SDK/NDK setup used to write this. Because [ObjectDetector] is an interface, you can
 * later add a Gradle dependency on `org.opencv:opencv:<version>` and drop in a real
 * `Imgproc.cvtColor` / `Imgproc.findContours` implementation behind the same interface without
 * touching the tracker, planner, controller, or UI at all.
 *
 * What this implementation actually does, entirely with the Android `Bitmap`/`Color` APIs:
 *
 * 1. Downsamples the ROI bitmap to a small working resolution (perf: connected-component
 *    labeling on a full-resolution frame at 15-30 FPS would be far too slow on a phone CPU).
 * 2. Converts every working pixel to HSV.
 * 3. Builds a foreground mask using HSV thresholds tuned for "saturated colorful blob" (fruit)
 *    or "very dark blob" (bomb) versus a duller background.
 * 4. Labels 4-connected components with an iterative flood fill (no recursion -> no stack
 *    overflow risk on large blobs).
 * 5. Filters components by pixel area to reject noise and oversized background regions.
 * 6. Classifies each surviving component as FRUIT or BOMB from its average HSV, and derives a
 *    confidence score from how strongly it matches the class heuristic.
 * 7. Scales bounding boxes back up to the original ROI bitmap coordinate space.
 *
 * This is a real, working, tunable heuristic pipeline — not a stub — but it is still a heuristic.
 * It will misclassify some objects, especially fruit skins that are dark (e.g. kiwi) or bombs
 * photographed with strong highlights. See [DetectorTuning] for the knobs to adjust.
 */
class OpenCvObjectDetector(
    private val tuning: DetectorTuning = DetectorTuning()
) : ObjectDetector {

    /** Tunable thresholds, pulled out so unit tests / settings screens can adjust them. */
    data class DetectorTuning(
        val workingWidth: Int = 160,
        val minSaturationForFruit: Float = 0.35f,
        val minValueForFruit: Float = 0.25f,
        val maxValueForBomb: Float = 0.22f,
        val maxSaturationForBomb: Float = 0.35f,
        val minComponentAreaPx: Int = 6,
        val maxComponentAreaFraction: Float = 0.35f
    )

    private var reusableWorkingPixels: IntArray? = null
    private var reusableLabels: IntArray? = null
    private var reusableStack: IntArray? = null

    override fun detect(bitmap: Bitmap, timestamp: Long): List<DetectedObject> {
        if (bitmap.width <= 0 || bitmap.height <= 0) return emptyList()

        val scale = tuning.workingWidth.toFloat() / bitmap.width.toFloat()
        val workingWidth = tuning.workingWidth.coerceAtLeast(16)
        val workingHeight = (bitmap.height * scale).toInt().coerceAtLeast(9)

        val scaledBitmap = Bitmap.createScaledBitmap(bitmap, workingWidth, workingHeight, true)
        try {
            val pixelCount = workingWidth * workingHeight
            val pixels = reusableWorkingPixels.let {
                if (it != null && it.size == pixelCount) it else IntArray(pixelCount).also { arr -> reusableWorkingPixels = arr }
            }
            scaledBitmap.getPixels(pixels, 0, workingWidth, 0, 0, workingWidth, workingHeight)

            val hsv = FloatArray(3)
            val hueBuf = FloatArray(pixelCount)
            val satBuf = FloatArray(pixelCount)
            val valBuf = FloatArray(pixelCount)
            val fgMask = BooleanArray(pixelCount)
            val bombMask = BooleanArray(pixelCount)

            for (i in 0 until pixelCount) {
                Color.colorToHSV(pixels[i], hsv)
                hueBuf[i] = hsv[0]
                satBuf[i] = hsv[1]
                valBuf[i] = hsv[2]
                val isFruitish = hsv[1] >= tuning.minSaturationForFruit && hsv[2] >= tuning.minValueForFruit
                val isBombish = hsv[2] <= tuning.maxValueForBomb && hsv[1] <= tuning.maxSaturationForBomb
                fgMask[i] = isFruitish || isBombish
                bombMask[i] = isBombish
            }

            val labels = reusableLabels.let {
                if (it != null && it.size == pixelCount) it else IntArray(pixelCount).also { arr -> reusableLabels = arr }
            }
            labels.fill(0)
            val stack = reusableStack.let {
                if (it != null && it.size >= pixelCount) it else IntArray(pixelCount).also { arr -> reusableStack = arr }
            }

            var nextLabel = 1
            val results = ArrayList<DetectedObject>()
            val maxArea = (pixelCount * tuning.maxComponentAreaFraction).toInt()

            for (start in 0 until pixelCount) {
                if (!fgMask[start] || labels[start] != 0) continue

                var stackTop = 0
                stack[stackTop++] = start
                labels[start] = nextLabel

                var minX = start % workingWidth
                var maxX = minX
                var minY = start / workingWidth
                var maxY = minY
                var sumX = 0L
                var sumY = 0L
                var sumHue = 0f
                var sumSat = 0f
                var sumVal = 0f
                var bombPixels = 0
                var area = 0

                while (stackTop > 0) {
                    val idx = stack[--stackTop]
                    val x = idx % workingWidth
                    val y = idx / workingWidth

                    area++
                    sumX += x
                    sumY += y
                    sumHue += hueBuf[idx]
                    sumSat += satBuf[idx]
                    sumVal += valBuf[idx]
                    if (bombMask[idx]) bombPixels++
                    if (x < minX) minX = x
                    if (x > maxX) maxX = x
                    if (y < minY) minY = y
                    if (y > maxY) maxY = y

                    // 4-connected neighbors
                    if (x > 0) {
                        val n = idx - 1
                        if (fgMask[n] && labels[n] == 0) { labels[n] = nextLabel; stack[stackTop++] = n }
                    }
                    if (x < workingWidth - 1) {
                        val n = idx + 1
                        if (fgMask[n] && labels[n] == 0) { labels[n] = nextLabel; stack[stackTop++] = n }
                    }
                    if (y > 0) {
                        val n = idx - workingWidth
                        if (fgMask[n] && labels[n] == 0) { labels[n] = nextLabel; stack[stackTop++] = n }
                    }
                    if (y < workingHeight - 1) {
                        val n = idx + workingWidth
                        if (fgMask[n] && labels[n] == 0) { labels[n] = nextLabel; stack[stackTop++] = n }
                    }

                    if (area > maxArea) {
                        // Bail out early on runaway components (likely background noise or a
                        // washed-out frame) so one bad frame can't stall the pipeline.
                        break
                    }
                }

                nextLabel++

                if (area < tuning.minComponentAreaPx || area > maxArea) continue

                val avgSat = sumSat / area
                val avgVal = sumVal / area
                val bombRatio = bombPixels.toFloat() / area.toFloat()

                val isBomb = bombRatio >= 0.6f
                val type = when {
                    isBomb -> ObjectClass.BOMB
                    avgSat >= tuning.minSaturationForFruit -> ObjectClass.FRUIT
                    else -> ObjectClass.UNKNOWN
                }
                if (type == ObjectClass.UNKNOWN) continue

                val confidence = if (isBomb) {
                    (bombRatio).coerceIn(0f, 1f)
                } else {
                    ((avgSat - tuning.minSaturationForFruit) / (1f - tuning.minSaturationForFruit) * 0.5f + 0.5f)
                        .coerceIn(0f, 1f)
                }

                val invScale = 1f / scale
                val boxWidth = (maxX - minX + 1) * invScale
                val boxHeight = (maxY - minY + 1) * invScale
                val centerX = (sumX.toFloat() / area) * invScale
                val centerY = (sumY.toFloat() / area) * invScale

                results.add(
                    DetectedObject(
                        type = type,
                        centerX = centerX,
                        centerY = centerY,
                        width = boxWidth,
                        height = boxHeight,
                        confidence = confidence,
                        timestamp = timestamp
                    )
                )
            }

            // Bombs first: downstream consumers that only look at the head of the list under
            // time pressure should still see bombs.
            return results.sortedByDescending { it.type == ObjectClass.BOMB }
        } finally {
            if (scaledBitmap !== bitmap) scaledBitmap.recycle()
        }
    }

    override fun release() {
        reusableWorkingPixels = null
        reusableLabels = null
        reusableStack = null
    }
}

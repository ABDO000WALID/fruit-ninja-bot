package com.example.fruitninjabot.planning

import com.example.fruitninjabot.detection.ObjectClass
import com.example.fruitninjabot.tracking.TrackedObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SafeSwipePlannerTest {

    private fun fruit(id: Int, x: Float, y: Float, confidence: Float = 0.9f) = TrackedObject(
        id = id, type = ObjectClass.FRUIT, x = x, y = y, vx = 0f, vy = 0f,
        confidence = confidence, lastSeen = 0L, hitStreak = 3
    )

    private fun bomb(id: Int, x: Float, y: Float, confidence: Float = 0.9f) = TrackedObject(
        id = id, type = ObjectClass.BOMB, x = x, y = y, vx = 0f, vy = 0f,
        confidence = confidence, lastSeen = 0L, hitStreak = 3
    )

    @Test
    fun noObjects_returnsNoTargets() {
        val planner = SafeSwipePlanner()
        val result = planner.plan(emptyList(), predictionHorizonMillis = 0L, nowMillis = 0L)
        assertTrue(result is PlanResult.Rejected)
        assertEquals(PlanResult.RejectionReason.NO_TARGETS, (result as PlanResult.Rejected).reason)
    }

    @Test
    fun onlyLowConfidenceFruit_isRejected() {
        val planner = SafeSwipePlanner(SafeSwipePlanner.PlannerConfig(minFruitConfidence = 0.6f))
        val result = planner.plan(listOf(fruit(1, 100f, 100f, confidence = 0.2f)), 0L, 0L)
        assertTrue(result is PlanResult.Rejected)
        assertEquals(
            PlanResult.RejectionReason.ALL_TARGETS_LOW_CONFIDENCE,
            (result as PlanResult.Rejected).reason
        )
    }

    @Test
    fun singleConfidentFruit_noBombs_isPlanned() {
        val planner = SafeSwipePlanner()
        val result = planner.plan(listOf(fruit(1, 100f, 100f)), 0L, 0L)
        assertTrue(result is PlanResult.Planned)
        val path = (result as PlanResult.Planned).path
        assertEquals(listOf(1), path.targetTrackIds)
        assertTrue(path.waypoints.size >= 2)
    }

    @Test
    fun bombDirectlyOnFruit_neverProducesPlanThroughIt() {
        val config = SafeSwipePlanner.PlannerConfig(bombSafetyRadiusPx = 200f, comboModeEnabled = false)
        val planner = SafeSwipePlanner(config)
        // Bomb sits essentially on top of the only fruit -> any swipe reaching the fruit must
        // pass through the bomb's large safety radius.
        val result = planner.plan(
            listOf(fruit(1, 100f, 100f), bomb(2, 100f, 100f)),
            predictionHorizonMillis = 0L,
            nowMillis = 0L
        )
        assertTrue(result is PlanResult.Rejected)
        assertEquals(
            PlanResult.RejectionReason.BOMB_TOO_CLOSE_TO_EVERY_CANDIDATE,
            (result as PlanResult.Rejected).reason
        )
    }

    @Test
    fun bombFarFromFruit_stillAllowsSwipe() {
        val config = SafeSwipePlanner.PlannerConfig(bombSafetyRadiusPx = 50f)
        val planner = SafeSwipePlanner(config)
        val result = planner.plan(
            listOf(fruit(1, 100f, 100f), bomb(2, 900f, 900f)),
            predictionHorizonMillis = 0L,
            nowMillis = 0L
        )
        assertTrue(result is PlanResult.Planned)
    }

    @Test
    fun everyGeneratedPath_isVerifiedSafe_forResultingPlan() {
        // Regression guard: whatever the planner returns as "Planned", re-verify with the same
        // geometry check independently here, so a future refactor can't silently reintroduce an
        // unsafe path without a fruit-planner-side bug also breaking this assertion.
        val config = SafeSwipePlanner.PlannerConfig(bombSafetyRadiusPx = 80f)
        val planner = SafeSwipePlanner(config)
        val bombPos = com.example.fruitninjabot.util.Point(300f, 300f)

        val result = planner.plan(
            listOf(
                fruit(1, 50f, 50f),
                fruit(2, 550f, 550f),
                bomb(3, bombPos.x, bombPos.y)
            ),
            predictionHorizonMillis = 0L,
            nowMillis = 0L
        )
        assertTrue(result is PlanResult.Planned)
        val path = (result as PlanResult.Planned).path
        for (i in 1 until path.waypoints.size) {
            val safe = !com.example.fruitninjabot.util.Geometry.segmentIntersectsCircle(
                path.waypoints[i - 1], path.waypoints[i], bombPos, config.bombSafetyRadiusPx
            )
            assertTrue("waypoint segment $i intersects bomb safety zone", safe)
        }
    }

    @Test
    fun comboMode_prefersMultiFruitOverSingle_whenBothSafe() {
        val config = SafeSwipePlanner.PlannerConfig(comboModeEnabled = true, maxFruitsPerSwipe = 3, minSwipeDistancePx = 40f)
        val planner = SafeSwipePlanner(config)
        // Three fruits close together in a line, nothing dangerous nearby.
        val result = planner.plan(
            listOf(fruit(1, 100f, 100f), fruit(2, 150f, 100f), fruit(3, 200f, 100f)),
            predictionHorizonMillis = 0L,
            nowMillis = 0L
        )
        assertTrue(result is PlanResult.Planned)
        val path = (result as PlanResult.Planned).path
        assertTrue("expected a combo of more than 1 fruit, got ${path.targetTrackIds}", path.targetTrackIds.size > 1)
    }

    @Test
    fun comboModeDisabled_neverReturnsMultiFruitPath() {
        val config = SafeSwipePlanner.PlannerConfig(comboModeEnabled = false)
        val planner = SafeSwipePlanner(config)
        val result = planner.plan(
            listOf(fruit(1, 100f, 100f), fruit(2, 150f, 100f), fruit(3, 200f, 100f)),
            predictionHorizonMillis = 0L,
            nowMillis = 0L
        )
        assertTrue(result is PlanResult.Planned)
        val path = (result as PlanResult.Planned).path
        assertEquals(1, path.targetTrackIds.size)
    }

    @Test
    fun predictionHorizon_projectsMovingFruitForward() {
        val planner = SafeSwipePlanner()
        val movingFruit = TrackedObject(
            id = 1, type = ObjectClass.FRUIT, x = 0f, y = 0f, vx = 1f, vy = 0f,
            confidence = 0.9f, lastSeen = 0L, hitStreak = 3
        )
        val result = planner.plan(listOf(movingFruit), predictionHorizonMillis = 100L, nowMillis = 0L)
        assertTrue(result is PlanResult.Planned)
        val path = (result as PlanResult.Planned).path
        // The middle waypoint of a single-fruit candidate is the fruit's projected center;
        // with vx=1px/ms and 100ms horizon, that should land near x=100, not x=0.
        val midpoint = path.waypoints[path.waypoints.size / 2]
        assertTrue("expected projected x near 100, got ${midpoint.x}", midpoint.x > 50f)
    }
}

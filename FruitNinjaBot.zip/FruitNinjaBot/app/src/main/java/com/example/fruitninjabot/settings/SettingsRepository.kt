package com.example.fruitninjabot.settings

import android.content.Context
import android.content.SharedPreferences
import com.example.fruitninjabot.util.NormalizedRoi

/**
 * Thin wrapper around [SharedPreferences] holding every user-tunable setting described in the
 * spec. Reads are cheap (SharedPreferences is memory-cached after first load) so callers can
 * call the getters freely from the bot's processing loop without a perceptible cost.
 */
class SettingsRepository(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    var detectionFps: Int
        get() = prefs.getInt(KEY_FPS, DEFAULT_FPS)
        set(value) = prefs.edit().putInt(KEY_FPS, value.coerceIn(5, 30)).apply()

    var swipeDurationMillis: Long
        get() = prefs.getLong(KEY_SWIPE_DURATION, DEFAULT_SWIPE_DURATION_MS)
        set(value) = prefs.edit().putLong(KEY_SWIPE_DURATION, value.coerceIn(40L, 800L)).apply()

    var bombSafetyRadiusPx: Float
        get() = prefs.getFloat(KEY_SAFETY_RADIUS, DEFAULT_SAFETY_RADIUS_PX)
        set(value) = prefs.edit().putFloat(KEY_SAFETY_RADIUS, value.coerceIn(10f, 1000f)).apply()

    var minConfidence: Float
        get() = prefs.getFloat(KEY_MIN_CONFIDENCE, DEFAULT_MIN_CONFIDENCE)
        set(value) = prefs.edit().putFloat(KEY_MIN_CONFIDENCE, value.coerceIn(0f, 1f)).apply()

    var maxFruitsPerSwipe: Int
        get() = prefs.getInt(KEY_MAX_FRUITS, DEFAULT_MAX_FRUITS)
        set(value) = prefs.edit().putInt(KEY_MAX_FRUITS, value.coerceIn(1, 10)).apply()

    var comboModeEnabled: Boolean
        get() = prefs.getBoolean(KEY_COMBO, true)
        set(value) = prefs.edit().putBoolean(KEY_COMBO, value).apply()

    var debugOverlayEnabled: Boolean
        get() = prefs.getBoolean(KEY_DEBUG_OVERLAY, false)
        set(value) = prefs.edit().putBoolean(KEY_DEBUG_OVERLAY, value).apply()

    var showDetectedObjects: Boolean
        get() = prefs.getBoolean(KEY_SHOW_OBJECTS, true)
        set(value) = prefs.edit().putBoolean(KEY_SHOW_OBJECTS, value).apply()

    var showPredictedPaths: Boolean
        get() = prefs.getBoolean(KEY_SHOW_PATHS, true)
        set(value) = prefs.edit().putBoolean(KEY_SHOW_PATHS, value).apply()

    var roiLeftFrac: Float
        get() = prefs.getFloat(KEY_ROI_LEFT, NormalizedRoi.defaultForGameplay().leftFrac)
        set(value) = prefs.edit().putFloat(KEY_ROI_LEFT, value).apply()

    var roiTopFrac: Float
        get() = prefs.getFloat(KEY_ROI_TOP, NormalizedRoi.defaultForGameplay().topFrac)
        set(value) = prefs.edit().putFloat(KEY_ROI_TOP, value).apply()

    var roiRightFrac: Float
        get() = prefs.getFloat(KEY_ROI_RIGHT, NormalizedRoi.defaultForGameplay().rightFrac)
        set(value) = prefs.edit().putFloat(KEY_ROI_RIGHT, value).apply()

    var roiBottomFrac: Float
        get() = prefs.getFloat(KEY_ROI_BOTTOM, NormalizedRoi.defaultForGameplay().bottomFrac)
        set(value) = prefs.edit().putFloat(KEY_ROI_BOTTOM, value).apply()

    fun currentRoi(): NormalizedRoi {
        return try {
            NormalizedRoi(roiLeftFrac, roiTopFrac, roiRightFrac, roiBottomFrac)
        } catch (e: IllegalArgumentException) {
            // Guards against a corrupted/edge-case saved ROI (e.g. from a bad calibration drag)
            // ever making the capture pipeline crash instead of falling back safely.
            NormalizedRoi.defaultForGameplay()
        }
    }

    fun saveRoi(roi: NormalizedRoi) {
        prefs.edit()
            .putFloat(KEY_ROI_LEFT, roi.leftFrac)
            .putFloat(KEY_ROI_TOP, roi.topFrac)
            .putFloat(KEY_ROI_RIGHT, roi.rightFrac)
            .putFloat(KEY_ROI_BOTTOM, roi.bottomFrac)
            .apply()
    }

    companion object {
        private const val PREFS_NAME = "fruit_ninja_bot_settings"

        private const val KEY_FPS = "detection_fps"
        private const val KEY_SWIPE_DURATION = "swipe_duration_ms"
        private const val KEY_SAFETY_RADIUS = "bomb_safety_radius_px"
        private const val KEY_MIN_CONFIDENCE = "min_confidence"
        private const val KEY_MAX_FRUITS = "max_fruits_per_swipe"
        private const val KEY_COMBO = "combo_mode_enabled"
        private const val KEY_DEBUG_OVERLAY = "debug_overlay_enabled"
        private const val KEY_SHOW_OBJECTS = "show_detected_objects"
        private const val KEY_SHOW_PATHS = "show_predicted_paths"
        private const val KEY_ROI_LEFT = "roi_left"
        private const val KEY_ROI_TOP = "roi_top"
        private const val KEY_ROI_RIGHT = "roi_right"
        private const val KEY_ROI_BOTTOM = "roi_bottom"

        const val DEFAULT_FPS = 15
        const val DEFAULT_SWIPE_DURATION_MS = 120L
        const val DEFAULT_SAFETY_RADIUS_PX = 120f
        const val DEFAULT_MIN_CONFIDENCE = 0.55f
        const val DEFAULT_MAX_FRUITS = 3
    }
}

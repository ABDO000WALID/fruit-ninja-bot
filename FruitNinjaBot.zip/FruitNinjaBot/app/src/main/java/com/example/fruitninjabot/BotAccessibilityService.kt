package com.example.fruitninjabot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import com.example.fruitninjabot.util.Point
import java.util.concurrent.atomic.AtomicBoolean

/**
 * The only component in this project that is allowed to touch the screen on the user's behalf.
 *
 * This service does not read window content (`canRetrieveWindowContent="false"` in
 * accessibility_service_config.xml) and does not act on [AccessibilityEvent]s — it exists purely
 * so [dispatchGesture] is available to draw the swipe paths that [BotController] plans.
 *
 * A single [AtomicBoolean] guards against overlapping gestures: Android will reject a second
 * concurrent gesture dispatch anyway, but this gives us a clean, explicit "busy" signal the
 * controller/state machine can check before even trying.
 */
class BotAccessibilityService : AccessibilityService() {

    private val gestureInFlight = AtomicBoolean(false)

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.i(TAG, "BotAccessibilityService connected")
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    // We don't need window-state events, but the accessibility framework requires this method
    // to exist regardless.
    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* intentionally empty */ }

    override fun onInterrupt() { /* intentionally empty */ }

    /**
     * Performs a smooth multi-point swipe through [waypoints] over [durationMillis].
     *
     * Returns false immediately (without touching the screen) if a gesture is already in
     * flight, if [waypoints] has fewer than 2 points, or if the service isn't connected — the
     * caller (BotController) treats any false return the same as "did not swipe" and does not
     * retry blindly.
     */
    fun performSwipe(
        waypoints: List<Point>,
        durationMillis: Long,
        onResult: (success: Boolean) -> Unit
    ): Boolean {
        if (waypoints.size < 2) {
            Log.w(TAG, "Refusing to swipe: fewer than 2 waypoints")
            return false
        }
        if (!gestureInFlight.compareAndSet(false, true)) {
            Log.w(TAG, "Refusing to swipe: a gesture is already in flight")
            return false
        }

        val path = Path()
        path.moveTo(waypoints[0].x, waypoints[0].y)
        for (i in 1 until waypoints.size) {
            path.lineTo(waypoints[i].x, waypoints[i].y)
        }

        val strokeDescription = GestureDescription.StrokeDescription(
            path,
            0L,
            durationMillis.coerceAtLeast(1L)
        )
        val gestureDescription = GestureDescription.Builder()
            .addStroke(strokeDescription)
            .build()

        val dispatched = dispatchGesture(
            gestureDescription,
            object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    gestureInFlight.set(false)
                    onResult(true)
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    gestureInFlight.set(false)
                    onResult(false)
                }
            },
            null
        )

        if (!dispatched) {
            gestureInFlight.set(false)
        }
        return dispatched
    }

    fun isBusy(): Boolean = gestureInFlight.get()

    companion object {
        private const val TAG = "BotAccessibilityService"

        @Volatile
        private var instance: BotAccessibilityService? = null

        fun getInstance(): BotAccessibilityService? = instance

        fun isServiceRunning(): Boolean = instance != null
    }
}

package com.example.fruitninjabot.detection

import android.graphics.Bitmap

/**
 * Abstraction over "given a bitmap of the game area, find candidate fruit/bomb regions".
 *
 * Keeping this as an interface means the concrete pixel-processing implementation
 * ([OpenCvObjectDetector] today, potentially a TensorFlow Lite model tomorrow) can be swapped
 * without touching [com.example.fruitninjabot.tracking.ObjectTracker],
 * [com.example.fruitninjabot.planning.PathPlanner], or [com.example.fruitninjabot.BotController].
 */
interface ObjectDetector {

    /**
     * Analyze [bitmap] (already cropped to the configured Region Of Interest) and return the
     * detected objects. Implementations must not mutate or recycle [bitmap] — the caller owns
     * its lifecycle. Implementations must be safe to call repeatedly from a background thread.
     *
     * @param bitmap the ROI-cropped frame to analyze.
     * @param timestamp capture timestamp in [android.os.SystemClock.elapsedRealtime] units, used
     *   to stamp the resulting [DetectedObject]s and to let the caller detect stale frames.
     */
    fun detect(bitmap: Bitmap, timestamp: Long): List<DetectedObject>

    /** Release any native/pixel buffers held by the detector. Safe to call multiple times. */
    fun release()
}

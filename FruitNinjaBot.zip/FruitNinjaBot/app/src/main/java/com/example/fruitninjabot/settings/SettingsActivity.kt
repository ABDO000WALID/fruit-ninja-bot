package com.example.fruitninjabot.settings

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.appcompat.app.AppCompatActivity
import com.example.fruitninjabot.FruitNinjaBotApp
import com.example.fruitninjabot.databinding.ActivitySettingsBinding
import com.example.fruitninjabot.overlay.DebugOverlayService

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private lateinit var settings: SettingsRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        settings = (application as FruitNinjaBotApp).settingsRepository
        loadCurrentValues()
        wireListeners()
    }

    private fun loadCurrentValues() {
        binding.sliderFps.value = settings.detectionFps.toFloat()
        binding.labelFps.text = "Detection FPS: ${settings.detectionFps}"

        binding.sliderSwipeDuration.value = settings.swipeDurationMillis.toFloat()
        binding.labelSwipeDuration.text = "Swipe duration: ${settings.swipeDurationMillis} ms"

        binding.sliderSafetyRadius.value = settings.bombSafetyRadiusPx
        binding.labelSafetyRadius.text = "Bomb safety radius: ${settings.bombSafetyRadiusPx.toInt()} px"

        binding.sliderMinConfidence.value = settings.minConfidence
        binding.labelMinConfidence.text = "Minimum confidence: %.2f".format(settings.minConfidence)

        binding.sliderMaxFruits.value = settings.maxFruitsPerSwipe.toFloat()
        binding.labelMaxFruits.text = "Max fruits per swipe: ${settings.maxFruitsPerSwipe}"

        binding.switchCombo.isChecked = settings.comboModeEnabled
        binding.switchDebugOverlay.isChecked = settings.debugOverlayEnabled
        binding.switchShowObjects.isChecked = settings.showDetectedObjects
        binding.switchShowPaths.isChecked = settings.showPredictedPaths
    }

    private fun wireListeners() {
        binding.sliderFps.addOnChangeListener { _, value, _ ->
            binding.labelFps.text = "Detection FPS: ${value.toInt()}"
        }
        binding.sliderSwipeDuration.addOnChangeListener { _, value, _ ->
            binding.labelSwipeDuration.text = "Swipe duration: ${value.toInt()} ms"
        }
        binding.sliderSafetyRadius.addOnChangeListener { _, value, _ ->
            binding.labelSafetyRadius.text = "Bomb safety radius: ${value.toInt()} px"
        }
        binding.sliderMinConfidence.addOnChangeListener { _, value, _ ->
            binding.labelMinConfidence.text = "Minimum confidence: %.2f".format(value)
        }
        binding.sliderMaxFruits.addOnChangeListener { _, value, _ ->
            binding.labelMaxFruits.text = "Max fruits per swipe: ${value.toInt()}"
        }

        binding.switchDebugOverlay.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked && !Settings.canDrawOverlays(this)) {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        android.net.Uri.parse("package:$packageName")
                    )
                )
            }
        }

        binding.btnSaveSettings.setOnClickListener { saveAndFinish() }
    }

    private fun saveAndFinish() {
        settings.detectionFps = binding.sliderFps.value.toInt()
        settings.swipeDurationMillis = binding.sliderSwipeDuration.value.toLong()
        settings.bombSafetyRadiusPx = binding.sliderSafetyRadius.value
        settings.minConfidence = binding.sliderMinConfidence.value
        settings.maxFruitsPerSwipe = binding.sliderMaxFruits.value.toInt()
        settings.comboModeEnabled = binding.switchCombo.isChecked
        settings.debugOverlayEnabled = binding.switchDebugOverlay.isChecked
        settings.showDetectedObjects = binding.switchShowObjects.isChecked
        settings.showPredictedPaths = binding.switchShowPaths.isChecked

        val app = application as FruitNinjaBotApp
        app.botController.updateFps(settings.detectionFps)

        val overlayIntent = Intent(this, DebugOverlayService::class.java)
        if (settings.debugOverlayEnabled) {
            if (Settings.canDrawOverlays(this)) {
                DebugOverlayService.showDetectedObjects = settings.showDetectedObjects
                DebugOverlayService.showPredictedPaths = settings.showPredictedPaths
                startService(overlayIntent)
            }
        } else {
            stopService(overlayIntent)
        }

        finish()
    }
}

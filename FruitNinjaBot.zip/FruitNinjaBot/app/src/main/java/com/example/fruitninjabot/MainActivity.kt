package com.example.fruitninjabot

import android.Manifest
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.fruitninjabot.databinding.ActivityMainBinding
import com.example.fruitninjabot.settings.SettingsActivity

class MainActivity : AppCompatActivity(), BotController.StatusListener {

    private lateinit var binding: ActivityMainBinding
    private lateinit var controller: BotController
    private val mainHandler = Handler(Looper.getMainLooper())

    private val mediaProjectionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val data = result.data
        if (result.resultCode == RESULT_OK && data != null) {
            controller.startCapture(result.resultCode, data)
            pushResolvedRoi()
        } else {
            Toast.makeText(this, "Screen capture permission was denied", Toast.LENGTH_LONG).show()
        }
    }

    private val overlayPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        if (Settings.canDrawOverlays(this)) {
            startService(Intent(this, com.example.fruitninjabot.overlay.DebugOverlayService::class.java))
        }
    }

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* proceed regardless; foreground service still works, notification may be hidden */ }

    private val calibrationLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        pushResolvedRoi()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        controller = (application as FruitNinjaBotApp).botController

        binding.btnEnableAccessibility.setOnClickListener { openAccessibilitySettings() }
        binding.btnStartCapture.setOnClickListener { requestMediaProjection() }
        binding.btnCalibrateRoi.setOnClickListener { launchCalibration() }
        binding.btnTestMode.setOnClickListener { startActivity(Intent(this, TestModeActivity::class.java)) }
        binding.btnTestSwipe.setOnClickListener { runTestSwipe() }
        binding.btnStartBot.setOnClickListener { controller.startBot() }
        binding.btnPause.setOnClickListener {
            if (controller.currentState() == BotState.PAUSED) controller.resumeBot() else controller.pauseBot()
        }
        binding.btnStop.setOnClickListener { controller.stopBot() }
        binding.btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        requestNotificationPermissionIfNeeded()
    }

    override fun onResume() {
        super.onResume()
        controller.statusListener = this
        // Publish an immediate status snapshot so the UI doesn't sit blank until the next frame.
        onStatusUpdate(
            BotStatus(
                state = controller.currentState(),
                accessibilityEnabled = isAccessibilityServiceEnabled(),
                captureActive = CaptureService.isCaptureActive
            )
        )
    }

    override fun onPause() {
        controller.statusListener = null
        super.onPause()
    }

    // ---- permission / setup flows -----------------------------------------------------

    private fun openAccessibilitySettings() {
        Toast.makeText(
            this,
            "Find \"${getString(R.string.accessibility_service_label)}\" and enable it",
            Toast.LENGTH_LONG
        ).show()
        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
    }

    private fun requestMediaProjection() {
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjectionLauncher.launch(manager.createScreenCaptureIntent())
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    private fun launchCalibration() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Grant \"Draw over other apps\" to calibrate visually", Toast.LENGTH_LONG).show()
        }
        calibrationLauncher.launch(Intent(this, RoiCalibrationActivity::class.java))
    }

    private fun runTestSwipe() {
        val metrics = resources.displayMetrics
        controller.performTestSwipe(metrics.widthPixels, metrics.heightPixels) { success ->
            mainHandler.post {
                val message = if (success) "Test swipe dispatched" else "Test swipe failed — check Accessibility is enabled"
                Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
            }
        }
    }

    /** Resolves the saved fractional ROI into pixel coordinates for the current display and
     * pushes it to CaptureService via the controller. */
    private fun pushResolvedRoi() {
        val metrics = resources.displayMetrics
        val roi = (application as FruitNinjaBotApp).settingsRepository.currentRoi()
        val pixelRect = roi.toPixelRect(metrics.widthPixels, metrics.heightPixels)
        controller.updateRoiPixels(pixelRect.left, pixelRect.top, pixelRect.right, pixelRect.bottom)
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val am = getSystemService(ACCESSIBILITY_SERVICE) as AccessibilityManager
        val enabledServices = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_GENERIC)
        return enabledServices.any { it.resolveInfo.serviceInfo.packageName == packageName } ||
            BotAccessibilityService.isServiceRunning()
    }

    // ---- BotController.StatusListener --------------------------------------------------

    override fun onStatusUpdate(status: BotStatus) {
        mainHandler.post {
            binding.textAccessibilityStatus.text = getString(
                R.string.status_accessibility,
                if (status.accessibilityEnabled) getString(R.string.on) else getString(R.string.off)
            )
            binding.textCaptureStatus.text = getString(
                R.string.status_capture,
                if (status.captureActive) getString(R.string.on) else getString(R.string.off)
            )
            val botLabel = when (status.state) {
                BotState.PAUSED -> getString(R.string.paused)
                BotState.STOPPED, BotState.ERROR -> getString(R.string.stopped)
                else -> getString(R.string.running)
            }
            binding.textBotStatus.text = getString(R.string.status_bot, botLabel)
            binding.textFps.text = getString(R.string.status_fps, status.fps)
            binding.textLatency.text = getString(R.string.status_latency, status.latencyMillis)
            binding.textFruits.text = getString(R.string.status_fruits, status.lastFruitCount)
            binding.textBombs.text = getString(R.string.status_bombs, status.lastBombCount)
            binding.textSwipes.text = getString(R.string.status_swipes, status.totalSwipes)
            binding.textPlansOk.text = getString(R.string.status_plans_ok, status.successfulPlans)
            binding.textPlansRejected.text = getString(R.string.status_plans_rejected, status.rejectedPlans)

            status.lastError?.let {
                if (status.state == BotState.ERROR) {
                    Toast.makeText(this, "Bot error: $it", Toast.LENGTH_LONG).show()
                }
            }
        }
    }
}

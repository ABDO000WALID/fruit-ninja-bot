package com.example.fruitninjabot.planning

import com.example.fruitninjabot.tracking.TrackedObject
import com.example.fruitninjabot.util.Geometry
import com.example.fruitninjabot.util.Point
import kotlin.math.min

/**
 * The bomb-avoiding, combo-seeking [PathPlanner] implementation described in the project spec.
 *
 * Golden rule, enforced structurally rather than just "by convention": [plan] only ever returns
 * [PlanResult.Planned] for a path that has already passed [isPathSafe] against every known bomb
 * (including predicted bomb movement). If nothing safe can be built, it returns a
 * [PlanResult.Rejected] with a specific reason instead of swiping. There is no code path that
 * dispatches a gesture without first passing that check.
 */
class SafeSwipePlanner(
    private var config: PlannerConfig = PlannerConfig()
) : PathPlanner {

    data class PlannerConfig(
        val minFruitConfidence: Float = 0.55f,
        /** Bombs are treated with extra caution: a lower bar is required to respect one. */
        val minBombConfidence: Float = 0.35f,
        val bombSafetyRadiusPx: Float = 120f,
        val swipeDurationMillis: Long = 120L,
        val minSwipeDistancePx: Float = 80f,
        val maxFruitsPerSwipe: Int = 3,
        val comboModeEnabled: Boolean = true
    )

    fun updateConfig(newConfig: PlannerConfig) {
        config = newConfig
    }

    fun currentConfig(): PlannerConfig = config

    override fun plan(
        trackedObjects: List<TrackedObject>,
        predictionHorizonMillis: Long,
        nowMillis: Long
    ): PlanResult {
        val projected = trackedObjects.map { obj ->
            val (px, py) = obj.predictPosition(predictionHorizonMillis)
            ProjectedObject(obj.id, obj.type, px, py, obj.confidence)
        }

        val allFruits = projected.filter { it.type == com.example.fruitninjabot.detection.ObjectClass.FRUIT }
        val confidentFruits = allFruits.filter { it.confidence >= config.minFruitConfidence }
        val bombs = projected
            .filter { it.type == com.example.fruitninjabot.detection.ObjectClass.BOMB }
            .filter { it.confidence >= config.minBombConfidence }

        if (allFruits.isEmpty()) return PlanResult.Rejected(PlanResult.RejectionReason.NO_TARGETS)
        if (confidentFruits.isEmpty()) {
            return PlanResult.Rejected(PlanResult.RejectionReason.ALL_TARGETS_LOW_CONFIDENCE)
        }

        val candidates = buildCandidatePaths(confidentFruits)
        if (candidates.isEmpty()) {
            return PlanResult.Rejected(PlanResult.RejectionReason.NO_SAFE_PATH_FOUND)
        }

        var anyRejectedDueToBomb = false
        val safeCandidates = candidates.filter { candidate ->
            val safe = isPathSafe(candidate.waypoints, bombs)
            if (!safe) anyRejectedDueToBomb = true
            safe
        }

        if (safeCandidates.isEmpty()) {
            return if (bombs.isNotEmpty() && anyRejectedDueToBomb) {
                PlanResult.Rejected(PlanResult.RejectionReason.BOMB_TOO_CLOSE_TO_EVERY_CANDIDATE)
            } else {
                PlanResult.Rejected(PlanResult.RejectionReason.NO_SAFE_PATH_FOUND)
            }
        }

        val best = safeCandidates.maxByOrNull { it.score } ?: return PlanResult.Rejected(
            PlanResult.RejectionReason.NO_SAFE_PATH_FOUND
        )

        return PlanResult.Planned(
            SwipePath(
                waypoints = best.waypoints,
                durationMillis = config.swipeDurationMillis,
                targetTrackIds = best.targetIds,
                score = best.score
            )
        )
    }

    // ---- internal candidate generation -------------------------------------------------

    private data class ProjectedObject(
        val id: Int,
        val type: com.example.fruitninjabot.detection.ObjectClass,
        val x: Float,
        val y: Float,
        val confidence: Float
    )

    private data class Candidate(
        val waypoints: List<Point>,
        val targetIds: List<Int>,
        val score: Float
    )

    /** Is this safe considering bomb positions and the configured safety radius? */
    private fun isPathSafe(waypoints: List<Point>, bombs: List<ProjectedObject>): Boolean {
        if (bombs.isEmpty()) return true
        for (i in 1 until waypoints.size) {
            val a = waypoints[i - 1]
            val b = waypoints[i]
            for (bomb in bombs) {
                val bombPoint = Point(bomb.x, bomb.y)
                if (Geometry.segmentIntersectsCircle(a, b, bombPoint, config.bombSafetyRadiusPx)) {
                    return false
                }
            }
        }
        return true
    }

    private fun buildCandidatePaths(fruits: List<ProjectedObject>): List<Candidate> {
        val candidates = ArrayList<Candidate>()

        // 1) Single-fruit swipes: always considered, they're the fallback if combos are unsafe.
        for (fruit in fruits) {
            candidates.add(buildSingleFruitCandidate(fruit))
        }

        // 2) Combo swipes: only if enabled and there's more than one target.
        if (config.comboModeEnabled && fruits.size > 1 && config.maxFruitsPerSwipe > 1) {
            candidates.addAll(buildComboCandidates(fruits))
        }

        return candidates
    }

    private fun buildSingleFruitCandidate(fruit: ProjectedObject): Candidate {
        val half = config.minSwipeDistancePx / 2f
        val start = Point(fruit.x - half, fruit.y + half)
        val end = Point(fruit.x + half, fruit.y - half)
        val center = Point(fruit.x, fruit.y)
        val waypoints = listOf(start, center, end)
        // Base score rewards higher-confidence targets and shorter paths.
        val length = Geometry.distance(start, end)
        val score = 10f + fruit.confidence * 5f - length * 0.01f
        return Candidate(waypoints, listOf(fruit.id), score)
    }

    /**
     * Greedily chains up to [PlannerConfig.maxFruitsPerSwipe] nearby fruits into one smooth
     * multi-point swipe, roughly ordered left-to-right (Fruit Ninja slices generally read as
     * continuous arcs, so a monotonic ordering produces a more natural, shorter path than
     * connecting fruits in an arbitrary order).
     */
    private fun buildComboCandidates(fruits: List<ProjectedObject>): List<Candidate> {
        val sorted = fruits.sortedBy { it.x }
        val results = ArrayList<Candidate>()

        // Try every contiguous window of size 2..maxFruitsPerSwipe along the sorted list. This
        // is intentionally simple (O(n * maxFruitsPerSwipe)) rather than an exhaustive subset
        // search, which would be exponential and unnecessary for a phone-sized target count.
        val maxGroup = min(config.maxFruitsPerSwipe, sorted.size)
        for (groupSize in 2..maxGroup) {
            for (startIdx in 0..(sorted.size - groupSize)) {
                val group = sorted.subList(startIdx, startIdx + groupSize)

                // Skip combos where consecutive fruits are implausibly far apart — that's not a
                // single continuous slice, it's two unrelated fruits that happen to share an x
                // range.
                var tooSpread = false
                for (i in 1 until group.size) {
                    if (Geometry.distance(group[i - 1].x, group[i - 1].y, group[i].x, group[i].y) >
                        config.minSwipeDistancePx * 6f
                    ) {
                        tooSpread = true
                        break
                    }
                }
                if (tooSpread) continue

                val half = config.minSwipeDistancePx / 2f
                val first = group.first()
                val last = group.last()
                val waypoints = ArrayList<Point>()
                waypoints.add(Point(first.x - half, first.y + half * 0.5f))
                for (f in group) waypoints.add(Point(f.x, f.y))
                waypoints.add(Point(last.x + half, last.y - half * 0.5f))

                var length = 0f
                for (i in 1 until waypoints.size) length += Geometry.distance(waypoints[i - 1], waypoints[i])
                val avgConfidence = group.map { it.confidence }.average().toFloat()

                // Multi-fruit combos are worth substantially more than a single fruit, scaling
                // with how many fruits they hit, then lightly penalized for extra travel length
                // so that among similar-value combos the shorter one wins (per spec: "prefer
                // shorter paths when scores are similar").
                val score = 10f * group.size + avgConfidence * 5f - length * 0.01f

                results.add(Candidate(waypoints, group.map { it.id }, score))
            }
        }
        return results
    }
}
